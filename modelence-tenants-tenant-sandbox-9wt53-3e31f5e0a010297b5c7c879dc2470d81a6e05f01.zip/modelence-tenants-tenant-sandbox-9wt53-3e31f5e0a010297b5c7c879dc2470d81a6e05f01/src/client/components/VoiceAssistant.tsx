import React, { useState, useRef, useEffect } from 'react';
import { Mic, MicOff, Volume2, VolumeX, X, MessageCircle, Sparkles } from 'lucide-react';
import { cn } from '@/client/lib/utils';
import { useNavigate } from 'react-router-dom';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  text: string;
}

// Sample responses for the AI assistant
const responses: Record<string, { text: string; action?: () => void }> = {
  // Greetings
  'assalamu alaikum': {
    text: 'Wa alaikum assalam wa rahmatullahi wa barakatuh! Peace be upon you too. How may I assist you today?',
  },
  hello: {
    text: 'Assalamu Alaikum! Peace be upon you. Welcome to Noor-ul-Quran. How can I help you today?',
  },
  hi: {
    text: 'Assalamu Alaikum! Welcome to Noor-ul-Quran. I am here to guide you through Islamic teachings. What would you like to learn?',
  },
  // Navigation
  quran: {
    text: 'I will take you to the Holy Quran section where you can read, listen, and understand the divine words of Allah.',
  },
  'read quran': {
    text: 'Taking you to the Holy Quran page. There you can read the complete Quran with Arabic text, translation, and audio recitation.',
  },
  prayer: {
    text: 'I will guide you to the Worship section where you can learn about Salah, its timings, and how to perform it correctly.',
  },
  dua: {
    text: 'Let me take you to our Duas collection. You will find essential daily supplications with Arabic text and translations.',
  },
  // Islamic knowledge
  'what is islam': {
    text: 'Islam is a monotheistic religion that teaches submission to the will of Allah. It is based on the Holy Quran and the teachings of Prophet Muhammad, peace be upon him. The five pillars are: Shahada (faith), Salah (prayer), Zakat (charity), Sawm (fasting), and Hajj (pilgrimage).',
  },
  'five pillars': {
    text: 'The five pillars of Islam are: 1) Shahada - declaration of faith, 2) Salah - five daily prayers, 3) Zakat - obligatory charity, 4) Sawm - fasting during Ramadan, and 5) Hajj - pilgrimage to Makkah for those who are able.',
  },
  fasting: {
    text: 'Fasting (Sawm) during Ramadan is one of the five pillars of Islam. Muslims fast from dawn to sunset, abstaining from food, drink, and other physical needs. It is a time for spiritual reflection, devotion, and self-discipline.',
  },
  ramadan: {
    text: 'Ramadan is the ninth month of the Islamic calendar, during which Muslims fast from dawn to sunset. It is the month in which the Quran was first revealed to Prophet Muhammad, peace be upon him. It ends with the celebration of Eid ul-Fitr.',
  },
  hajj: {
    text: 'Hajj is the annual Islamic pilgrimage to Makkah, required once in a lifetime for every able Muslim. It takes place in the month of Dhul Hijjah and involves rituals commemorating the actions of Prophet Ibrahim and his family.',
  },
  // Quran recitation
  'recite fatiha': {
    text: 'Bismillahir Rahmanir Raheem. Alhamdu lillahi rabbil alameen. Ar-Rahmanir Raheem. Maliki yawmid deen. Iyyaka nabudu wa iyyaka nastaeen. Ihdinas siratal mustaqeem. Siratal latheena anamta alayhim, ghayril maghdubi alayhim wa lad dalleen. Ameen.',
  },
  'ayatul kursi': {
    text: 'Ayatul Kursi is verse 255 of Surah Al-Baqarah. It is known as the Throne Verse and is one of the most powerful verses of the Quran. It speaks of Allah\'s sovereignty over the heavens and the earth.',
  },
  // Help
  help: {
    text: 'I am your Islamic guide assistant. You can ask me about: the Quran, prayers (Salah), duas, fasting, Hajj, Islamic history, or navigate to different sections of the website. Just ask!',
  },
};

function getResponse(input: string): { text: string; action?: () => void } {
  const normalizedInput = input.toLowerCase().trim();

  // Check for exact matches first
  if (responses[normalizedInput]) {
    return responses[normalizedInput];
  }

  // Check for partial matches
  for (const [key, response] of Object.entries(responses)) {
    if (normalizedInput.includes(key) || key.includes(normalizedInput)) {
      return response;
    }
  }

  // Default response
  return {
    text: 'SubhanAllah! I am here to help you learn about Islam. You can ask me about the Quran, prayers, duas, fasting, or any other Islamic topic. May Allah guide us all.',
  };
}

export default function VoiceAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      text: 'Assalamu Alaikum! I am your Islamic guide. Ask me anything about Islam, the Quran, prayers, or navigate the website using voice commands.',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const navigate = useNavigate();

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Initialize speech synthesis
  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      synthRef.current = window.speechSynthesis;
    }
  }, []);

  // Initialize speech recognition
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition();
        recognitionRef.current.continuous = false;
        recognitionRef.current.interimResults = false;
        recognitionRef.current.lang = 'en-US';

        recognitionRef.current.onresult = (event) => {
          const transcript = event.results[0][0].transcript;
          handleUserMessage(transcript);
        };

        recognitionRef.current.onend = () => {
          setIsListening(false);
        };

        recognitionRef.current.onerror = () => {
          setIsListening(false);
        };
      }
    }
  }, []);

  const speak = (text: string) => {
    if (synthRef.current && !isMuted) {
      synthRef.current.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 1;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      synthRef.current.speak(utterance);
    }
  };

  const handleUserMessage = (text: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      text,
    };

    setMessages((prev) => [...prev, userMessage]);

    // Process the response
    setTimeout(() => {
      const response = getResponse(text);
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        text: response.text,
      };

      setMessages((prev) => [...prev, assistantMessage]);
      speak(response.text);

      // Handle navigation
      const normalizedText = text.toLowerCase();
      if (normalizedText.includes('quran') || normalizedText.includes('read')) {
        setTimeout(() => navigate('/quran'), 2000);
      } else if (normalizedText.includes('prayer') || normalizedText.includes('salah') || normalizedText.includes('worship')) {
        setTimeout(() => navigate('/worship'), 2000);
      } else if (normalizedText.includes('dua')) {
        setTimeout(() => navigate('/dua'), 2000);
      } else if (normalizedText.includes('book')) {
        setTimeout(() => navigate('/books'), 2000);
      } else if (normalizedText.includes('history')) {
        setTimeout(() => navigate('/history'), 2000);
      } else if (normalizedText.includes('about')) {
        setTimeout(() => navigate('/about'), 2000);
      }
    }, 500);
  };

  const startListening = () => {
    if (recognitionRef.current) {
      setIsListening(true);
      recognitionRef.current.start();
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputText.trim()) {
      handleUserMessage(inputText);
      setInputText('');
    }
  };

  const toggleMute = () => {
    if (synthRef.current && isSpeaking) {
      synthRef.current.cancel();
      setIsSpeaking(false);
    }
    setIsMuted(!isMuted);
  };

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setIsOpen(true)}
        className={cn(
          'fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full shadow-lg transition-all duration-300 flex items-center justify-center',
          'bg-gradient-to-br from-islamic-green-600 to-islamic-green-800 hover:from-islamic-green-500 hover:to-islamic-green-700',
          'hover:scale-110 hover:shadow-xl',
          isOpen && 'hidden'
        )}
      >
        <div className="relative">
          <MessageCircle className="w-6 h-6 text-white" />
          <Sparkles className="absolute -top-1 -right-1 w-3 h-3 text-islamic-gold-400 animate-pulse" />
        </div>
      </button>

      {/* Chat panel */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-96 max-w-[calc(100vw-3rem)] bg-white rounded-2xl shadow-2xl border border-islamic-gold-200 overflow-hidden animate-in slide-in-from-bottom-4 duration-300">
          {/* Header */}
          <div className="bg-gradient-to-r from-islamic-green-700 to-islamic-green-800 text-white p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-islamic-gold-500 rounded-full flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-islamic-green-900" />
                </div>
                <div>
                  <h3 className="font-semibold">Islamic Guide</h3>
                  <p className="text-xs text-white/70">Voice & Text Assistant</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={toggleMute}
                  className="p-2 rounded-full hover:bg-white/10 transition-colors"
                >
                  {isMuted ? (
                    <VolumeX className="w-5 h-5" />
                  ) : (
                    <Volume2 className={cn('w-5 h-5', isSpeaking && 'text-islamic-gold-400')} />
                  )}
                </button>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2 rounded-full hover:bg-white/10 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="h-80 overflow-y-auto p-4 space-y-4 bg-islamic-cream">
            {messages.map((message) => (
              <div
                key={message.id}
                className={cn(
                  'flex',
                  message.type === 'user' ? 'justify-end' : 'justify-start'
                )}
              >
                <div
                  className={cn(
                    'max-w-[80%] rounded-2xl px-4 py-2 text-sm',
                    message.type === 'user'
                      ? 'bg-islamic-green-700 text-white rounded-br-sm'
                      : 'bg-white text-gray-800 rounded-bl-sm shadow-sm border border-islamic-gold-100'
                  )}
                >
                  {message.text}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-gray-200 bg-white">
            <form onSubmit={handleSubmit} className="flex items-center gap-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Type or use voice..."
                className="flex-1 px-4 py-2 rounded-full border border-gray-200 focus:outline-none focus:ring-2 focus:ring-islamic-green-500 focus:border-transparent text-sm"
              />
              <button
                type="button"
                onClick={isListening ? stopListening : startListening}
                className={cn(
                  'w-10 h-10 rounded-full flex items-center justify-center transition-all',
                  isListening
                    ? 'bg-red-500 hover:bg-red-600 animate-pulse'
                    : 'bg-islamic-green-600 hover:bg-islamic-green-700'
                )}
              >
                {isListening ? (
                  <MicOff className="w-5 h-5 text-white" />
                ) : (
                  <Mic className="w-5 h-5 text-white" />
                )}
              </button>
            </form>
            <p className="text-xs text-gray-400 mt-2 text-center">
              {isListening ? 'Listening...' : 'Click the mic or type your question'}
            </p>
          </div>
        </div>
      )}
    </>
  );
}
