import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  BookOpen,
  Home,
  Info,
  HandHeart,
  BookText,
  History,
  Search,
  Menu,
  X,
  Moon,
  BookOpenCheck,
  Code,
} from 'lucide-react';
import { cn } from '@/client/lib/utils';

interface IslamicLayoutProps {
  children: React.ReactNode;
  className?: string;
}

const navLinks = [
  { path: '/', label: 'Home', icon: Home },
  { path: '/about', label: 'About', icon: Info },
  { path: '/quran', label: 'Holy Quran', icon: BookOpen },
  { path: '/worship', label: 'Worship', icon: HandHeart },
  { path: '/dua', label: 'Duas', icon: Moon },
  { path: '/books', label: 'Books', icon: BookText },
  { path: '/history', label: 'History', icon: History },
];

function IslamicHeader() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const [isSearchOpen, setIsSearchOpen] = React.useState(false);
  const location = useLocation();

  return (
    <header className="sticky top-0 z-50 bg-gradient-to-r from-[#0f5e3b] via-[#0d4f32] to-[#0f5e3b] text-white shadow-lg">
      {/* Top decorative border */}
      <div className="h-1 gold-gradient" />

      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 hover:opacity-90 transition-opacity">
            <div className="relative">
              <div className="w-10 h-10 bg-islamic-gold-500 rounded-full flex items-center justify-center">
                <BookOpenCheck className="w-6 h-6 text-[#0f5e3b]" />
              </div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-islamic-gold-300 rounded-full animate-pulse" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-wide">Noor-ul-Quran</h1>
              <p className="text-xs text-islamic-gold-200">Light of the Quran</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = location.pathname === link.path;
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={cn(
                    'flex items-center gap-2 px-3 py-2 rounded-lg transition-all duration-200',
                    isActive
                      ? 'bg-islamic-gold-500 text-[#0f5e3b] font-semibold'
                      : 'text-white/90 hover:bg-white/10 hover:text-white'
                  )}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm">{link.label}</span>
                </Link>
              );
            })}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {/* Search */}
            <button
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="p-2 rounded-lg hover:bg-white/10 transition-colors"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg hover:bg-white/10 transition-colors"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Search bar */}
        {isSearchOpen && (
          <div className="pb-4 animate-in slide-in-from-top duration-200">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search Quran verses, duas, topics..."
                className="w-full pl-10 pr-4 py-2 rounded-lg bg-white text-gray-800 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-islamic-gold-400"
                autoFocus
              />
            </div>
          </div>
        )}
      </div>

      {/* Mobile Navigation */}
      {isMobileMenuOpen && (
        <nav className="lg:hidden bg-[#0a3d27]/95 backdrop-blur-sm border-t border-white/10 animate-in slide-in-from-top duration-200">
          <div className="max-w-7xl mx-auto px-4 py-4 space-y-2">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = location.pathname === link.path;
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={cn(
                    'flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200',
                    isActive
                      ? 'bg-islamic-gold-500 text-[#0f5e3b] font-semibold'
                      : 'text-white/90 hover:bg-white/10'
                  )}
                >
                  <Icon className="w-5 h-5" />
                  <span>{link.label}</span>
                </Link>
              );
            })}
          </div>
        </nav>
      )}
    </header>
  );
}

function IslamicFooter() {
  return (
    <footer className="bg-[#0a3d27] text-white">
      {/* Top decorative border */}
      <div className="h-1 gold-gradient" />

      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* About */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-islamic-gold-500 rounded-full flex items-center justify-center">
                <BookOpenCheck className="w-5 h-5 text-[#0f5e3b]" />
              </div>
              <h3 className="text-lg font-bold">Noor-ul-Quran</h3>
            </div>
            <p className="text-white/70 text-sm leading-relaxed">
              Spreading the light of Islamic knowledge through the Holy Quran,
              authentic Hadith, and the teachings of our beloved Prophet Muhammad (PBUH).
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-4 text-islamic-gold-400">Quick Links</h3>
            <ul className="space-y-2">
              {navLinks.slice(0, 5).map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-white/70 hover:text-islamic-gold-400 transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Daily Reminder */}
          <div>
            <h3 className="text-lg font-bold mb-4 text-islamic-gold-400">Daily Reminder</h3>
            <div className="arabic-text text-xl text-islamic-gold-300 mb-2">
              بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
            </div>
            <p className="text-white/70 text-sm">
              "In the name of Allah, the Most Gracious, the Most Merciful"
            </p>
          </div>
        </div>

        {/* Developer Credit */}
        <div className="mt-8 pt-8 border-t border-white/10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-white/50 text-sm">
              Noor-ul-Quran - Illuminating hearts with divine knowledge
            </p>
            <div className="flex items-center gap-2 text-islamic-gold-400">
              <Code className="w-4 h-4" />
              <span className="text-sm font-medium">Developed by Hafiz Muhammad Ubaid</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default function IslamicLayout({ children, className }: IslamicLayoutProps) {
  return (
    <div className="flex flex-col min-h-screen bg-white">
      <IslamicHeader />
      <main className={cn('flex-1', className)}>
        {children}
      </main>
      <IslamicFooter />
    </div>
  );
}
