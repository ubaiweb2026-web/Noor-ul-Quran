import { useState, useEffect } from 'react';
import { BookOpenCheck, Code } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
  duration?: number;
}

export default function SplashScreen({ onComplete, duration = 3000 }: SplashScreenProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const fadeTimer = setTimeout(() => {
      setFadeOut(true);
    }, duration - 500);

    const completeTimer = setTimeout(() => {
      setIsVisible(false);
      onComplete();
    }, duration);

    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(completeTimer);
    };
  }, [duration, onComplete]);

  if (!isVisible) return null;

  return (
    <div
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center bg-gradient-to-br from-[#0f5e3b] to-[#0a3d27] transition-opacity duration-500 ${
        fadeOut ? 'opacity-0' : 'opacity-100'
      }`}
    >
      {/* Background pattern */}
      <div className="absolute inset-0 star-pattern opacity-20" />

      {/* Main content */}
      <div className="relative z-10 flex flex-col items-center">
        {/* Logo animation */}
        <div className="relative mb-8">
          {/* Glow effect */}
          <div className="absolute inset-0 bg-islamic-gold-400/30 rounded-full blur-3xl animate-pulse" />

          {/* Logo */}
          <div className="relative w-32 h-32 bg-islamic-gold-500 rounded-full flex items-center justify-center animate-float shadow-2xl">
            <BookOpenCheck className="w-16 h-16 text-[#0f5e3b]" />
          </div>
        </div>

        {/* Arabic title */}
        <h1 className="arabic-text text-4xl md:text-5xl text-islamic-gold-400 mb-2 animate-pulse">
          نُورُ القُرآن
        </h1>

        {/* English title */}
        <h2 className="text-2xl md:text-3xl font-bold text-white mb-2">
          Noor-ul-Quran
        </h2>

        <p className="text-white/70 mb-8">
          Light of the Quran
        </p>

        {/* Loading indicator */}
        <div className="flex gap-1 mb-12">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className="w-2 h-2 rounded-full bg-islamic-gold-400 animate-bounce"
              style={{ animationDelay: `${i * 0.15}s` }}
            />
          ))}
        </div>

        {/* Bismillah */}
        <div className="text-center mb-8">
          <p className="arabic-text text-xl text-white/80">
            بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
          </p>
          <p className="text-white/60 text-sm mt-2 italic">
            "In the name of Allah, the Most Gracious, the Most Merciful"
          </p>
        </div>
      </div>

      {/* Developer credit at bottom */}
      <div className="absolute bottom-8 left-0 right-0 text-center">
        <div className="flex items-center justify-center gap-2 text-islamic-gold-400">
          <Code className="w-4 h-4" />
          <span className="text-sm font-medium">Developed by Hafiz Muhammad Ubaid</span>
        </div>
      </div>
    </div>
  );
}
