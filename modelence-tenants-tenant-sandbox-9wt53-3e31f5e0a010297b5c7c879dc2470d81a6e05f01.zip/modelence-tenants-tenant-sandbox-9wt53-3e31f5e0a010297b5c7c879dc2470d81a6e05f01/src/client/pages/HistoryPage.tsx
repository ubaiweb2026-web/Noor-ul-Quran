import { useState } from 'react';
import { History, Swords, Calendar, MapPin, Users, ChevronDown, ChevronUp, Star } from 'lucide-react';
import IslamicLayout from '@/client/components/IslamicLayout';
import VoiceAssistant from '@/client/components/VoiceAssistant';
import { cn } from '@/client/lib/utils';

const categories = [
  { id: 'all', label: 'All Events' },
  { id: 'battles', label: 'Major Battles' },
  { id: 'events', label: 'Historical Events' },
  { id: 'caliphate', label: 'Caliphate Era' },
];

const historicalEvents = [
  {
    id: 1,
    category: 'events',
    year: '610 CE',
    title: 'First Revelation',
    arabicTitle: 'نزول الوحي',
    location: 'Cave of Hira, Makkah',
    description: 'Prophet Muhammad (PBUH) received the first revelation from Allah through Angel Jibreel in the Cave of Hira during Ramadan.',
    details: 'The first verses revealed were from Surah Al-Alaq: "Read! In the name of your Lord who created." This marked the beginning of the prophethood and the revelation of the Quran over the next 23 years.',
    significance: [
      'Beginning of Islam as a religion',
      'Start of Quranic revelation',
      'Prophet Muhammad (PBUH) appointed as the final messenger',
    ],
  },
  {
    id: 2,
    category: 'events',
    year: '622 CE',
    title: 'The Hijrah (Migration)',
    arabicTitle: 'الهجرة النبوية',
    location: 'From Makkah to Madinah',
    description: 'Prophet Muhammad (PBUH) and his companions migrated from Makkah to Madinah to escape persecution and establish the first Islamic state.',
    details: 'The Hijrah marks the beginning of the Islamic calendar. The Prophet (PBUH) established the Constitution of Madinah, which became a model of governance and religious coexistence.',
    significance: [
      'Beginning of the Islamic calendar',
      'Establishment of the first Muslim state',
      'Brotherhood between Muhajirun and Ansar',
    ],
  },
  {
    id: 3,
    category: 'battles',
    year: '624 CE (2 AH)',
    title: 'Battle of Badr',
    arabicTitle: 'غزوة بدر',
    location: 'Badr, near Madinah',
    description: 'The first major battle between Muslims and the Quraysh of Makkah. Despite being outnumbered (313 vs 1000), Muslims achieved a decisive victory.',
    details: 'This battle is mentioned in the Quran as "Yawm al-Furqan" (Day of Criterion). Allah sent angels to assist the Muslim army. The victory established the Muslims as a force to be reckoned with.',
    significance: [
      'First major military victory for Muslims',
      'Divine intervention mentioned in Quran',
      'Strengthened Muslim morale and position',
      'Many key Quraysh leaders killed',
    ],
    muslimForce: '313',
    enemyForce: '1,000',
    outcome: 'Muslim Victory',
  },
  {
    id: 4,
    category: 'battles',
    year: '625 CE (3 AH)',
    title: 'Battle of Uhud',
    arabicTitle: 'غزوة أحد',
    location: 'Mount Uhud, near Madinah',
    description: 'The second major battle where Muslims faced the Quraysh army. Initial victory turned to setback when archers left their positions.',
    details: 'This battle taught important lessons about obedience to the Prophet (PBUH). The Prophet himself was injured. 70 Muslims were martyred, including Hamza (RA), the Prophet\'s uncle.',
    significance: [
      'Lesson in following commands',
      'Test of faith after Badr victory',
      'Martyrdom of Hamza (RA)',
      'Quran verses revealed about the battle',
    ],
    muslimForce: '700',
    enemyForce: '3,000',
    outcome: 'Strategic Setback',
  },
  {
    id: 5,
    category: 'battles',
    year: '627 CE (5 AH)',
    title: 'Battle of the Trench (Khandaq)',
    arabicTitle: 'غزوة الخندق',
    location: 'Madinah',
    description: 'A coalition of Arab tribes besieged Madinah. Muslims dug a trench as a defensive strategy, which was suggested by Salman al-Farsi (RA).',
    details: 'The siege lasted about a month. The enemy alliance eventually broke apart due to internal disputes and harsh weather. This was the last major offensive by the Quraysh against Muslims.',
    significance: [
      'Innovative defense strategy',
      'End of Quraysh military threat',
      'Unity of Muslim community under siege',
      'Exposure of hypocrites in Madinah',
    ],
    muslimForce: '3,000',
    enemyForce: '10,000',
    outcome: 'Muslim Victory',
  },
  {
    id: 6,
    category: 'events',
    year: '628 CE (6 AH)',
    title: 'Treaty of Hudaybiyyah',
    arabicTitle: 'صلح الحديبية',
    location: 'Hudaybiyyah, near Makkah',
    description: 'A peace treaty between Muslims and the Quraysh of Makkah, which seemed unfavorable but was called a "clear victory" by Allah in the Quran.',
    details: 'The treaty allowed for 10 years of peace and permitted Muslims to return for Umrah the following year. This peace enabled the rapid spread of Islam across Arabia.',
    significance: [
      'Called "Fath Mubin" (Clear Victory) in Quran',
      'Diplomatic recognition of Muslim state',
      'Enabled peaceful spread of Islam',
      'Many converted to Islam during peace period',
    ],
  },
  {
    id: 7,
    category: 'events',
    year: '630 CE (8 AH)',
    title: 'Conquest of Makkah',
    arabicTitle: 'فتح مكة',
    location: 'Makkah',
    description: 'The peaceful conquest of Makkah after Quraysh violated the Treaty of Hudaybiyyah. The Prophet (PBUH) entered with 10,000 Muslims.',
    details: 'The Prophet (PBUH) forgave the people of Makkah and purified the Kaaba from idols. Most Makkans accepted Islam. The Prophet recited: "Truth has come and falsehood has vanished."',
    significance: [
      'Peaceful conquest with minimal bloodshed',
      'Purification of the Kaaba',
      'General amnesty granted to enemies',
      'Islam spread throughout Arabia',
    ],
  },
  {
    id: 8,
    category: 'battles',
    year: '630 CE (8 AH)',
    title: 'Battle of Hunayn',
    arabicTitle: 'غزوة حنين',
    location: 'Hunayn Valley, near Makkah',
    description: 'A battle against the Hawazin and Thaqif tribes shortly after the conquest of Makkah.',
    details: 'Despite initial setbacks due to ambush, the Muslim army regrouped and won decisively. This battle is mentioned in the Quran (9:25-26).',
    significance: [
      'Mentioned in the Quran',
      'Lesson against overconfidence in numbers',
      'Consolidation of Islamic rule',
    ],
    muslimForce: '12,000',
    enemyForce: '4,000',
    outcome: 'Muslim Victory',
  },
  {
    id: 9,
    category: 'caliphate',
    year: '632-634 CE',
    title: 'Caliphate of Abu Bakr (RA)',
    arabicTitle: 'خلافة أبي بكر الصديق',
    location: 'Madinah',
    description: 'The first Caliph of Islam. He unified Arabia, compiled the Quran, and suppressed the Ridda (apostasy) wars.',
    details: 'Abu Bakr (RA) preserved the unity of the Muslim community after the Prophet\'s death. He began the collection of the Quran and initiated the expansion of Islam beyond Arabia.',
    significance: [
      'Preserved Muslim unity after Prophet\'s death',
      'Initiated Quran compilation',
      'Suppressed false prophets',
      'Began conquest of Persia and Byzantine territories',
    ],
  },
  {
    id: 10,
    category: 'caliphate',
    year: '634-644 CE',
    title: 'Caliphate of Umar (RA)',
    arabicTitle: 'خلافة عمر بن الخطاب',
    location: 'Madinah',
    description: 'The second Caliph who oversaw massive expansion of the Islamic state including the conquest of Jerusalem, Persia, and Egypt.',
    details: 'Umar (RA) established many administrative systems including the Islamic calendar, the Bayt al-Mal (treasury), and an efficient postal system. He was known for his justice and simplicity.',
    significance: [
      'Major territorial expansion',
      'Conquest of Jerusalem',
      'Established Islamic administrative systems',
      'Known for exemplary justice',
    ],
  },
];

interface EventCardProps {
  event: typeof historicalEvents[0];
  isExpanded: boolean;
  onToggle: () => void;
}

function EventCard({ event, isExpanded, onToggle }: EventCardProps) {
  const isBattle = event.category === 'battles';

  return (
    <div className="mb-6">
      <button
        onClick={onToggle}
        className="w-full islamic-card p-6 text-left hover:shadow-lg transition-shadow"
      >
        <div className="flex items-start gap-4">
          {/* Icon */}
          <div className={cn(
            'w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0',
            isBattle
              ? 'bg-gradient-to-br from-red-500 to-rose-600'
              : 'bg-gradient-to-br from-islamic-green-600 to-islamic-green-800'
          )}>
            {isBattle ? (
              <Swords className="w-7 h-7 text-white" />
            ) : (
              <History className="w-7 h-7 text-white" />
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="px-2 py-0.5 bg-islamic-gold-100 text-islamic-gold-700 text-xs rounded-full font-medium">
                    {event.year}
                  </span>
                  {event.outcome && (
                    <span className={cn(
                      'px-2 py-0.5 text-xs rounded-full font-medium',
                      event.outcome === 'Muslim Victory'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-amber-100 text-amber-700'
                    )}>
                      {event.outcome}
                    </span>
                  )}
                </div>
                <h3 className="text-lg font-semibold text-islamic-green-800">
                  {event.title}
                </h3>
                <p className="arabic-text text-islamic-gold-600 mt-1">
                  {event.arabicTitle}
                </p>
              </div>
              {isExpanded ? (
                <ChevronUp className="w-6 h-6 text-gray-400 flex-shrink-0" />
              ) : (
                <ChevronDown className="w-6 h-6 text-gray-400 flex-shrink-0" />
              )}
            </div>

            <div className="flex items-center gap-2 mt-2 text-sm text-gray-500">
              <MapPin className="w-4 h-4" />
              <span>{event.location}</span>
            </div>

            <p className="text-gray-600 text-sm mt-3">
              {event.description}
            </p>
          </div>
        </div>
      </button>

      {isExpanded && (
        <div className="mt-4 pl-0 md:pl-20 animate-in slide-in-from-top duration-300">
          <div className="islamic-card p-6 space-y-6">
            {/* Battle forces */}
            {event.muslimForce && (
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-islamic-green-50 rounded-lg text-center">
                  <Users className="w-6 h-6 text-islamic-green-600 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-islamic-green-800">{event.muslimForce}</p>
                  <p className="text-sm text-gray-600">Muslim Force</p>
                </div>
                <div className="p-4 bg-red-50 rounded-lg text-center">
                  <Users className="w-6 h-6 text-red-600 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-red-800">{event.enemyForce}</p>
                  <p className="text-sm text-gray-600">Enemy Force</p>
                </div>
              </div>
            )}

            {/* Details */}
            <div>
              <h4 className="text-lg font-semibold text-islamic-green-800 mb-3">Details</h4>
              <p className="text-gray-700 leading-relaxed">
                {event.details}
              </p>
            </div>

            {/* Significance */}
            <div>
              <h4 className="text-lg font-semibold text-islamic-green-800 mb-3">Historical Significance</h4>
              <ul className="space-y-2">
                {event.significance.map((item, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <Star className="w-5 h-5 text-islamic-gold-500 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function HistoryPage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [expandedEvent, setExpandedEvent] = useState<number | null>(1);

  const filteredEvents = historicalEvents.filter((event) => {
    return selectedCategory === 'all' || event.category === selectedCategory;
  });

  return (
    <IslamicLayout>
      {/* Hero Section */}
      <section className="relative py-16 overflow-hidden">
        <div className="absolute inset-0 islamic-gradient" />
        <div className="absolute inset-0 star-pattern opacity-20" />

        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full text-islamic-gold-300 text-sm mb-6">
            <History className="w-4 h-4" />
            <span>Islamic History</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            History of Islam
          </h1>

          <p className="text-xl text-white/80 max-w-2xl mx-auto">
            Explore the rich history of Islam from the first revelation to the
            expansion of the Islamic civilization. Learn about important events,
            battles, and the era of the Rightly Guided Caliphs.
          </p>
        </div>
      </section>

      {/* Category tabs */}
      <section className="sticky top-[65px] z-40 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex overflow-x-auto py-3 gap-2 scrollbar-hide">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={cn(
                  'px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all',
                  selectedCategory === category.id
                    ? 'bg-islamic-green-700 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                )}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8 flex items-center gap-3">
            <Calendar className="w-6 h-6 text-islamic-green-700" />
            <h2 className="text-2xl font-bold text-islamic-green-800">
              Timeline of Events
            </h2>
          </div>

          {/* Timeline line */}
          <div className="relative">
            <div className="absolute left-7 top-0 bottom-0 w-0.5 bg-islamic-green-200 hidden md:block" />

            {filteredEvents.map((event) => (
              <EventCard
                key={event.id}
                event={event}
                isExpanded={expandedEvent === event.id}
                onToggle={() => setExpandedEvent(expandedEvent === event.id ? null : event.id)}
              />
            ))}
          </div>

          {filteredEvents.length === 0 && (
            <div className="text-center py-12">
              <History className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No events found in this category.</p>
            </div>
          )}
        </div>
      </section>

      <VoiceAssistant />
    </IslamicLayout>
  );
}
