import { useState, useRef, useEffect, useCallback } from 'react';
import {
  Play,
  Pause,
  BookOpen,
  Search,
  Heart,
  Volume2,
  VolumeX,
  SkipBack,
  SkipForward,
  ChevronDown,
  ChevronUp,
  User,
  X,
  Check,
  Loader2,
} from 'lucide-react';
import IslamicLayout from '@/client/components/IslamicLayout';
import VoiceAssistant from '@/client/components/VoiceAssistant';
import { cn } from '@/client/lib/utils';
import { surahs, reciters, getSurahAudioUrl, alFatihaAyahs, type Surah, type Reciter, type Ayah } from '@/client/data/quranData';

// LocalStorage keys
const FAVORITES_KEY = 'noorulquran_favorites';
const LAST_RECITER_KEY = 'noorulquran_reciter';

function getFavorites(): number[] {
  try {
    const stored = localStorage.getItem(FAVORITES_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

function saveFavorites(favorites: number[]) {
  localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites));
}

function getLastReciter(): string {
  return localStorage.getItem(LAST_RECITER_KEY) || 'mishary_alafasy';
}

function saveLastReciter(reciterId: string) {
  localStorage.setItem(LAST_RECITER_KEY, reciterId);
}

// Sound wave animation component
function SoundWave({ isPlaying }: { isPlaying: boolean }) {
  if (!isPlaying) return null;

  return (
    <div className="flex items-center gap-0.5 h-5">
      {[...Array(5)].map((_, i) => (
        <div
          key={i}
          className="sound-wave-bar"
          style={{ animationDelay: `${i * 0.1}s` }}
        />
      ))}
    </div>
  );
}

// Reciter selector modal
function ReciterModal({
  isOpen,
  onClose,
  selectedReciter,
  onSelect,
}: {
  isOpen: boolean;
  onClose: () => void;
  selectedReciter: string;
  onSelect: (id: string) => void;
}) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[80vh] overflow-hidden">
        <div className="sticky top-0 bg-[#0f5e3b] text-white p-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold">Select Reciter</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-2 overflow-y-auto max-h-[60vh]">
          {reciters.map((reciter) => (
            <button
              key={reciter.id}
              onClick={() => {
                onSelect(reciter.id);
                onClose();
              }}
              className={cn(
                'w-full p-4 rounded-xl text-left transition-all flex items-center gap-4',
                selectedReciter === reciter.id
                  ? 'bg-[#0f5e3b] text-white'
                  : 'bg-gray-50 hover:bg-gray-100'
              )}
            >
              <div className={cn(
                'w-12 h-12 rounded-full flex items-center justify-center',
                selectedReciter === reciter.id ? 'bg-white/20' : 'bg-[#0f5e3b]/10'
              )}>
                <User className={cn(
                  'w-6 h-6',
                  selectedReciter === reciter.id ? 'text-white' : 'text-[#0f5e3b]'
                )} />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold">{reciter.name}</h3>
                <p className={cn(
                  'text-sm',
                  selectedReciter === reciter.id ? 'text-white/70' : 'text-gray-500'
                )}>
                  {reciter.style}
                </p>
                <p className={cn(
                  'arabic-text text-sm mt-1',
                  selectedReciter === reciter.id ? 'text-white/80' : 'text-gray-600'
                )}>
                  {reciter.arabicName}
                </p>
              </div>
              {selectedReciter === reciter.id && (
                <Check className="w-5 h-5" />
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// Surah card component
function SurahCard({
  surah,
  isFavorite,
  onToggleFavorite,
  onSelect,
  isSelected,
}: {
  surah: Surah;
  isFavorite: boolean;
  onToggleFavorite: () => void;
  onSelect: () => void;
  isSelected: boolean;
}) {
  return (
    <div
      className={cn(
        'quran-card cursor-pointer',
        isSelected && 'ring-2 ring-[#0f5e3b]'
      )}
      onClick={onSelect}
    >
      <div className="flex items-center p-4 gap-4">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0f5e3b] to-[#0d4f32] text-white flex items-center justify-center font-bold text-lg">
          {surah.id}
        </div>

        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-gray-900">{surah.name}</h3>
          <p className="text-sm text-gray-500">{surah.meaning} - {surah.verses} verses</p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="arabic-text text-xl text-[#0f5e3b]">{surah.arabicName}</p>
            <p className="text-xs text-gray-400">{surah.type}</p>
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite();
            }}
            className={cn(
              'w-10 h-10 rounded-full flex items-center justify-center transition-all',
              isFavorite
                ? 'bg-red-50 text-red-500'
                : 'bg-gray-50 text-gray-400 hover:bg-gray-100'
            )}
          >
            <Heart className={cn('w-5 h-5', isFavorite && 'fill-current')} />
          </button>
        </div>
      </div>
    </div>
  );
}

// Audio player component
function AudioPlayer({
  surah,
  reciter,
  onChangeReciter,
  onPrevious,
  onNext,
  canGoPrevious,
  canGoNext,
}: {
  surah: Surah;
  reciter: Reciter;
  onChangeReciter: () => void;
  onPrevious: () => void;
  onNext: () => void;
  canGoPrevious: boolean;
  canGoNext: boolean;
}) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const audioUrl = getSurahAudioUrl(reciter.id, surah.id);

  useEffect(() => {
    // Reset player when surah or reciter changes
    setIsPlaying(false);
    setCurrentTime(0);
    setDuration(0);
    setError(null);
    if (audioRef.current) {
      audioRef.current.load();
    }
  }, [surah.id, reciter.id]);

  const togglePlay = useCallback(() => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      setIsLoading(true);
      audioRef.current.play().catch(() => {
        setError('Unable to play audio. Please try another reciter.');
        setIsLoading(false);
      });
    }
    setIsPlaying(!isPlaying);
  }, [isPlaying]);

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setDuration(audioRef.current.duration);
      setIsLoading(false);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseFloat(e.target.value);
    if (audioRef.current) {
      audioRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume;
    }
    setIsMuted(newVolume === 0);
  };

  const toggleMute = () => {
    if (audioRef.current) {
      audioRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
      <audio
        ref={audioRef}
        src={audioUrl}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onEnded={() => setIsPlaying(false)}
        onCanPlay={() => setIsLoading(false)}
        onError={() => {
          setError('Audio playback error. Please try another reciter.');
          setIsLoading(false);
          setIsPlaying(false);
        }}
        preload="metadata"
      />

      {/* Header */}
      <div className="bg-gradient-to-r from-[#0f5e3b] to-[#0d4f32] p-4 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-lg">{surah.name}</h3>
            <p className="text-white/70 text-sm">{surah.meaning}</p>
          </div>
          <div className="arabic-text text-2xl">{surah.arabicName}</div>
        </div>

        {/* Reciter info */}
        <button
          onClick={onChangeReciter}
          className="mt-3 flex items-center gap-2 bg-white/10 hover:bg-white/20 rounded-lg px-3 py-2 transition-colors"
        >
          <User className="w-4 h-4" />
          <span className="text-sm">{reciter.name}</span>
          <ChevronDown className="w-4 h-4 ml-auto" />
        </button>
      </div>

      {/* Player controls */}
      <div className="p-4">
        {error ? (
          <div className="text-center py-4">
            <p className="text-red-500 text-sm mb-2">{error}</p>
            <button
              onClick={onChangeReciter}
              className="text-[#0f5e3b] text-sm font-medium hover:underline"
            >
              Try another reciter
            </button>
          </div>
        ) : (
          <>
            {/* Progress bar */}
            <div className="mb-4">
              <input
                type="range"
                min="0"
                max={duration || 0}
                value={currentTime}
                onChange={handleSeek}
                className="w-full h-2 bg-gray-200 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[#0f5e3b]"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-4">
              <button
                onClick={onPrevious}
                disabled={!canGoPrevious}
                className={cn(
                  'w-10 h-10 rounded-full flex items-center justify-center transition-all',
                  canGoPrevious
                    ? 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                    : 'bg-gray-50 text-gray-300 cursor-not-allowed'
                )}
              >
                <SkipBack className="w-5 h-5" />
              </button>

              <button
                onClick={togglePlay}
                disabled={isLoading}
                className="w-16 h-16 rounded-full bg-gradient-to-br from-[#0f5e3b] to-[#0d4f32] text-white flex items-center justify-center shadow-lg hover:shadow-xl transition-all"
              >
                {isLoading ? (
                  <Loader2 className="w-7 h-7 animate-spin" />
                ) : isPlaying ? (
                  <Pause className="w-7 h-7" />
                ) : (
                  <Play className="w-7 h-7 ml-1" />
                )}
              </button>

              <button
                onClick={onNext}
                disabled={!canGoNext}
                className={cn(
                  'w-10 h-10 rounded-full flex items-center justify-center transition-all',
                  canGoNext
                    ? 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                    : 'bg-gray-50 text-gray-300 cursor-not-allowed'
                )}
              >
                <SkipForward className="w-5 h-5" />
              </button>
            </div>

            {/* Volume control */}
            <div className="flex items-center justify-center gap-3 mt-4">
              <button onClick={toggleMute} className="text-gray-500 hover:text-gray-700">
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-5 h-5" />
                ) : (
                  <Volume2 className="w-5 h-5" />
                )}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-24 h-2 bg-gray-200 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[#0f5e3b]"
              />
            </div>

            {/* Sound wave */}
            <div className="flex justify-center mt-3">
              <SoundWave isPlaying={isPlaying} />
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// Ayah display component
function AyahDisplay({
  ayah,
  isHighlighted,
  translationLanguage,
}: {
  ayah: Ayah;
  isHighlighted: boolean;
  translationLanguage: 'english' | 'urdu';
}) {
  return (
    <div className={cn(
      'p-6 rounded-xl transition-all duration-300',
      isHighlighted ? 'bg-[#e8f5ec] border-2 border-[#0f5e3b]/30' : 'bg-gray-50'
    )}>
      {/* Ayah number */}
      <div className="flex items-center justify-between mb-4">
        <span className="w-8 h-8 rounded-full bg-[#0f5e3b] text-white flex items-center justify-center text-sm font-medium">
          {ayah.number}
        </span>
      </div>

      {/* Arabic text */}
      <p className="quran-arabic text-3xl md:text-4xl text-gray-900 mb-6 leading-loose text-right">
        {ayah.arabic}
      </p>

      {/* Translation */}
      <p className="text-gray-700 leading-relaxed">
        {translationLanguage === 'urdu' && ayah.translationUrdu
          ? ayah.translationUrdu
          : ayah.translation}
      </p>

      {/* Transliteration */}
      {ayah.transliteration && (
        <p className="text-gray-500 italic text-sm mt-3">
          {ayah.transliteration}
        </p>
      )}
    </div>
  );
}

export default function QuranPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [favorites, setFavorites] = useState<number[]>([]);
  const [selectedReciterId, setSelectedReciterId] = useState<string>('mishary_alafasy');
  const [selectedSurah, setSelectedSurah] = useState<Surah | null>(null);
  const [showReciterModal, setShowReciterModal] = useState(false);
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [translationLanguage, setTranslationLanguage] = useState<'english' | 'urdu'>('english');
  const [showSurahReader, setShowSurahReader] = useState(false);

  // Load favorites and reciter preference
  useEffect(() => {
    setFavorites(getFavorites());
    setSelectedReciterId(getLastReciter());
  }, []);

  const selectedReciter = reciters.find(r => r.id === selectedReciterId) || reciters[0];

  const filteredSurahs = surahs.filter((surah) => {
    const matchesSearch = searchQuery === '' ||
      surah.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      surah.arabicName.includes(searchQuery) ||
      surah.meaning.toLowerCase().includes(searchQuery.toLowerCase()) ||
      surah.id.toString() === searchQuery;

    const matchesFavorites = !showFavoritesOnly || favorites.includes(surah.id);

    return matchesSearch && matchesFavorites;
  });

  const toggleFavorite = (surahId: number) => {
    const newFavorites = favorites.includes(surahId)
      ? favorites.filter(id => id !== surahId)
      : [...favorites, surahId];
    setFavorites(newFavorites);
    saveFavorites(newFavorites);
  };

  const handleReciterChange = (reciterId: string) => {
    setSelectedReciterId(reciterId);
    saveLastReciter(reciterId);
  };

  const handleSelectSurah = (surah: Surah) => {
    setSelectedSurah(surah);
    setShowSurahReader(true);
  };

  const goToPreviousSurah = () => {
    if (selectedSurah && selectedSurah.id > 1) {
      const prevSurah = surahs.find(s => s.id === selectedSurah.id - 1);
      if (prevSurah) setSelectedSurah(prevSurah);
    }
  };

  const goToNextSurah = () => {
    if (selectedSurah && selectedSurah.id < 114) {
      const nextSurah = surahs.find(s => s.id === selectedSurah.id + 1);
      if (nextSurah) setSelectedSurah(nextSurah);
    }
  };

  return (
    <IslamicLayout>
      {/* Hero Section */}
      <section className="relative py-12 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0f5e3b] to-[#0a3d27]" />
        <div className="absolute inset-0 star-pattern opacity-20" />

        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full text-white/80 text-sm mb-4">
            <BookOpen className="w-4 h-4" />
            <span>The Holy Quran</span>
          </div>

          <h1 className="arabic-text text-4xl md:text-5xl text-white mb-2">
            القرآن الكريم
          </h1>
          <h2 className="text-2xl text-white/80 mb-4">
            The Noble Quran
          </h2>

          <p className="text-white/70 max-w-xl mx-auto">
            Listen to beautiful recitations by world-renowned Qaris.
            Read with translations and follow along with highlighted ayahs.
          </p>
        </div>
      </section>

      {/* Search and filters */}
      <section className="sticky top-[65px] z-30 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-3">
          <div className="flex items-center gap-3">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search Surah by name, number, or meaning..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#0f5e3b] focus:border-transparent"
              />
            </div>

            {/* Favorites filter */}
            <button
              onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
              className={cn(
                'flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium transition-all',
                showFavoritesOnly
                  ? 'bg-red-50 text-red-600 border-2 border-red-200'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              )}
            >
              <Heart className={cn('w-4 h-4', showFavoritesOnly && 'fill-current')} />
              <span className="hidden sm:inline">Favorites</span>
            </button>

            {/* Reciter selector */}
            <button
              onClick={() => setShowReciterModal(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#0f5e3b] text-white font-medium hover:bg-[#0d4f32] transition-colors"
            >
              <User className="w-4 h-4" />
              <span className="hidden sm:inline">Reciter</span>
            </button>
          </div>
        </div>
      </section>

      {/* Main content */}
      <section className="py-6 px-4">
        <div className="max-w-4xl mx-auto">
          {showSurahReader && selectedSurah ? (
            /* Surah Reader View */
            <div className="space-y-6">
              <button
                onClick={() => setShowSurahReader(false)}
                className="flex items-center gap-2 text-[#0f5e3b] hover:underline"
              >
                <ChevronUp className="w-4 h-4 rotate-[-90deg]" />
                <span>Back to Surah List</span>
              </button>

              {/* Audio Player */}
              <AudioPlayer
                surah={selectedSurah}
                reciter={selectedReciter}
                onChangeReciter={() => setShowReciterModal(true)}
                onPrevious={goToPreviousSurah}
                onNext={goToNextSurah}
                canGoPrevious={selectedSurah.id > 1}
                canGoNext={selectedSurah.id < 114}
              />

              {/* Translation language toggle */}
              <div className="flex items-center justify-center gap-2">
                <span className="text-sm text-gray-500">Translation:</span>
                <div className="flex rounded-lg overflow-hidden border border-gray-200">
                  <button
                    onClick={() => setTranslationLanguage('english')}
                    className={cn(
                      'px-4 py-2 text-sm font-medium transition-colors',
                      translationLanguage === 'english'
                        ? 'bg-[#0f5e3b] text-white'
                        : 'bg-white text-gray-600 hover:bg-gray-50'
                    )}
                  >
                    English
                  </button>
                  <button
                    onClick={() => setTranslationLanguage('urdu')}
                    className={cn(
                      'px-4 py-2 text-sm font-medium transition-colors',
                      translationLanguage === 'urdu'
                        ? 'bg-[#0f5e3b] text-white'
                        : 'bg-white text-gray-600 hover:bg-gray-50'
                    )}
                  >
                    Urdu
                  </button>
                </div>
              </div>

              {/* Ayahs display - Show Al-Fatiha as sample */}
              {selectedSurah.id === 1 ? (
                <div className="space-y-4">
                  {alFatihaAyahs.map((ayah) => (
                    <AyahDisplay
                      key={ayah.number}
                      ayah={ayah}
                      isHighlighted={false}
                      translationLanguage={translationLanguage}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-gray-50 rounded-2xl">
                  <BookOpen className="w-16 h-16 text-[#0f5e3b]/30 mx-auto mb-4" />
                  <p className="text-gray-500 mb-2">
                    Full Quran text with translations coming soon.
                  </p>
                  <p className="text-sm text-gray-400">
                    For now, enjoy the beautiful audio recitation of {selectedSurah.name}.
                  </p>
                </div>
              )}
            </div>
          ) : (
            /* Surah List View */
            <>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-gray-900">
                  {showFavoritesOnly ? 'Favorite Surahs' : 'All Surahs'} ({filteredSurahs.length})
                </h2>
              </div>

              {filteredSurahs.length > 0 ? (
                <div className="grid gap-3">
                  {filteredSurahs.map((surah) => (
                    <SurahCard
                      key={surah.id}
                      surah={surah}
                      isFavorite={favorites.includes(surah.id)}
                      onToggleFavorite={() => toggleFavorite(surah.id)}
                      onSelect={() => handleSelectSurah(surah)}
                      isSelected={selectedSurah?.id === surah.id}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">
                    {showFavoritesOnly
                      ? 'No favorite surahs yet. Click the heart icon to add favorites.'
                      : 'No surahs found matching your search.'}
                  </p>
                </div>
              )}
            </>
          )}
        </div>
      </section>

      {/* Reciter Modal */}
      <ReciterModal
        isOpen={showReciterModal}
        onClose={() => setShowReciterModal(false)}
        selectedReciter={selectedReciterId}
        onSelect={handleReciterChange}
      />

      <VoiceAssistant />
    </IslamicLayout>
  );
}
