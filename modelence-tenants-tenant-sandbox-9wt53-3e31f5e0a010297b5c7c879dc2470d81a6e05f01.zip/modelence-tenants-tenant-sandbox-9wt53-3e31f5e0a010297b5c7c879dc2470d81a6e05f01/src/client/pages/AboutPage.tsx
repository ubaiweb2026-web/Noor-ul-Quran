import { BookOpenCheck, Heart, Users, Globe, Award, Target, Code, User } from 'lucide-react';
import IslamicLayout from '@/client/components/IslamicLayout';
import VoiceAssistant from '@/client/components/VoiceAssistant';

const values = [
  {
    icon: BookOpenCheck,
    title: 'Authentic Knowledge',
    description: 'We present Islamic teachings from authentic sources including the Holy Quran and verified Hadith collections.',
  },
  {
    icon: Heart,
    title: 'Spiritual Growth',
    description: 'Our mission is to help Muslims strengthen their connection with Allah through understanding and practice.',
  },
  {
    icon: Users,
    title: 'Community Building',
    description: 'We aim to unite the Ummah through shared knowledge and understanding of our beautiful religion.',
  },
  {
    icon: Globe,
    title: 'Accessible Learning',
    description: 'Islamic education should be available to everyone, regardless of their background or location.',
  },
];

const features = [
  'Complete Holy Quran with all 114 Surahs',
  'High-quality audio recitations by famous Qaris',
  'Arabic text with English and Urdu translations',
  'Famous reciters: Al-Sudais, Mishary Alafasy, Maher Al-Muaiqly',
  'Comprehensive worship guides for Salah, fasting, and Hajj',
  'Collection of authentic duas for daily life',
  'Islamic books and Hadith collections',
  'History of Islam and important events',
  'AI-powered voice assistant for guidance',
  'Favorite Surahs feature for quick access',
  'Search Surah by name, number, or meaning',
  'Mobile-friendly design for learning on the go',
];

export default function AboutPage() {
  return (
    <IslamicLayout>
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0f5e3b] to-[#0a3d27]" />
        <div className="absolute inset-0 star-pattern opacity-20" />

        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full text-islamic-gold-300 text-sm mb-6">
            <Target className="w-4 h-4" />
            <span>Our Mission</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
            About Noor-ul-Quran
          </h1>

          <p className="text-xl text-white/80 leading-relaxed">
            Noor-ul-Quran is dedicated to spreading the light of Islamic knowledge
            to Muslims around the world. Our platform provides authentic resources
            for learning about the Holy Quran, Islamic teachings, and the beautiful
            traditions of our faith.
          </p>
        </div>
      </section>

      {/* Mission Statement */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="islamic-card p-8 md:p-12">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-full bg-[#e8f5ec] flex items-center justify-center">
                <Award className="w-6 h-6 text-[#0f5e3b]" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-[#0f5e3b]">
                Our Mission
              </h2>
            </div>

            <div className="space-y-4 text-gray-700 leading-relaxed">
              <p>
                In the name of Allah, the Most Gracious, the Most Merciful. Noor-ul-Quran
                was established with a singular purpose: to make Islamic knowledge accessible
                to every Muslim, regardless of their location, language, or background.
              </p>

              <p>
                We believe that the light of the Quran should illuminate every heart, and
                the teachings of Prophet Muhammad (peace be upon him) should guide every
                step. Our platform serves as a bridge connecting believers with the
                authentic sources of Islamic wisdom.
              </p>

              <p>
                Through modern technology and traditional scholarship, we strive to present
                Islam in its pure form - a religion of peace, mercy, and guidance. We are
                committed to accuracy, authenticity, and accessibility in everything we do.
              </p>
            </div>

            {/* Inspirational verse */}
            <div className="mt-8 p-6 bg-[#e8f5ec] rounded-xl border border-[#0f5e3b]/20">
              <div className="arabic-text text-2xl text-[#0f5e3b] mb-3 text-center">
                وَمَا أَرْسَلْنَاكَ إِلَّا رَحْمَةً لِّلْعَالَمِينَ
              </div>
              <p className="text-center text-gray-600 italic">
                "And We have not sent you, [O Muhammad], except as a mercy to the worlds."
              </p>
              <p className="text-center text-islamic-gold-600 text-sm mt-2">
                Surah Al-Anbiya (21:107)
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Developer Section */}
      <section className="py-16 px-4 bg-gradient-to-br from-[#0f5e3b] to-[#0a3d27]">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Developer
            </h2>
            <p className="text-white/70">
              The mind behind Noor-ul-Quran
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 md:p-12 border border-white/20">
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="w-32 h-32 rounded-full bg-islamic-gold-500 flex items-center justify-center">
                <User className="w-16 h-16 text-[#0f5e3b]" />
              </div>
              <div className="text-center md:text-left flex-1">
                <h3 className="text-2xl md:text-3xl font-bold text-white mb-2">
                  Hafiz Muhammad Ubaid
                </h3>
                <div className="flex items-center justify-center md:justify-start gap-2 text-islamic-gold-400 mb-4">
                  <Code className="w-5 h-5" />
                  <span>Application Developer</span>
                </div>
                <p className="text-white/80 leading-relaxed">
                  Dedicated to creating Islamic applications that help Muslims around the world
                  connect with their faith. This application is developed with love and devotion
                  to serve the Ummah and spread the beautiful teachings of Islam through technology.
                </p>
                <div className="mt-6 p-4 bg-white/10 rounded-xl">
                  <p className="arabic-text text-xl text-islamic-gold-300 mb-2">
                    جَزَاكُمُ اللَّهُ خَيْرًا
                  </p>
                  <p className="text-white/70 text-sm">
                    "May Allah reward you with goodness"
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#0f5e3b] mb-4">
              Our Core Values
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              The principles that guide our mission to spread Islamic knowledge
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <div key={index} className="islamic-card p-6 flex gap-4">
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#0f5e3b] to-[#0a3d27] flex items-center justify-center flex-shrink-0">
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-[#0f5e3b] mb-2">
                      {value.title}
                    </h3>
                    <p className="text-gray-600">{value.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#0f5e3b] mb-4">
              What We Offer
            </h2>
            <p className="text-gray-600">
              Comprehensive Islamic resources at your fingertips
            </p>
          </div>

          <div className="islamic-card p-8">
            <div className="grid md:grid-cols-2 gap-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-[#e8f5ec] flex items-center justify-center flex-shrink-0 mt-0.5">
                    <svg className="w-4 h-4 text-[#0f5e3b]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 px-4 bg-[#0f5e3b] relative overflow-hidden">
        <div className="absolute inset-0 star-pattern opacity-20" />

        <div className="relative max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Begin Your Journey
          </h2>
          <p className="text-white/80 text-lg mb-8">
            May Allah guide us all on the straight path and accept our efforts
            in spreading His divine message. Join us in this noble mission.
          </p>

          <div className="arabic-text text-2xl text-islamic-gold-400">
            رَبِّ زِدْنِي عِلْمًا
          </div>
          <p className="text-white/90 mt-2 italic">
            "My Lord, increase me in knowledge."
          </p>
          <p className="text-islamic-gold-400 text-sm mt-1">
            Surah Ta-Ha (20:114)
          </p>
        </div>
      </section>

      <VoiceAssistant />
    </IslamicLayout>
  );
}
