import { useState } from 'react';
import { HandHeart, Clock, Moon, Wallet, Plane, ChevronDown, ChevronUp, Check } from 'lucide-react';
import IslamicLayout from '@/client/components/IslamicLayout';
import VoiceAssistant from '@/client/components/VoiceAssistant';
import { cn } from '@/client/lib/utils';

const worshipTypes = [
  {
    id: 'salah',
    icon: HandHeart,
    title: 'Salah (Prayer)',
    arabicTitle: 'الصلاة',
    description: 'The five daily prayers are the most important pillar of Islam after the Shahada.',
    color: 'from-emerald-500 to-green-600',
    content: {
      intro: 'Salah is the second pillar of Islam. It is a direct connection between the worshipper and Allah. Muslims pray five times a day facing the Kaaba in Makkah.',
      prayers: [
        { name: 'Fajr', time: 'Before sunrise', rakats: '2 Sunnah + 2 Fard', arabic: 'الفجر' },
        { name: 'Dhuhr', time: 'After midday', rakats: '4 Sunnah + 4 Fard + 2 Sunnah', arabic: 'الظهر' },
        { name: 'Asr', time: 'Afternoon', rakats: '4 Sunnah + 4 Fard', arabic: 'العصر' },
        { name: 'Maghrib', time: 'After sunset', rakats: '3 Fard + 2 Sunnah', arabic: 'المغرب' },
        { name: 'Isha', time: 'Night', rakats: '4 Sunnah + 4 Fard + 2 Sunnah + 3 Witr', arabic: 'العشاء' },
      ],
      steps: [
        { title: 'Wudu (Ablution)', description: 'Purify yourself by performing wudu - washing hands, mouth, nose, face, arms, head, and feet.' },
        { title: 'Niyyah (Intention)', description: 'Make sincere intention in your heart for the specific prayer you are about to perform.' },
        { title: 'Takbir', description: 'Raise your hands to your ears and say "Allahu Akbar" (Allah is the Greatest).' },
        { title: 'Qiyam (Standing)', description: 'Stand straight with hands folded, recite Surah Al-Fatiha and another surah.' },
        { title: 'Ruku (Bowing)', description: 'Bow with hands on knees saying "Subhana Rabbiyal Azeem" three times.' },
        { title: 'Sujood (Prostration)', description: 'Prostrate with forehead, nose, palms, knees, and toes touching the ground, saying "Subhana Rabbiyal Ala".' },
        { title: 'Tashahhud', description: 'Sit and recite the Tashahhud, then complete with Salam to both sides.' },
      ],
    },
  },
  {
    id: 'sawm',
    icon: Moon,
    title: 'Sawm (Fasting)',
    arabicTitle: 'الصوم',
    description: 'Fasting during Ramadan is obligatory for all adult Muslims who are able.',
    color: 'from-purple-500 to-violet-600',
    content: {
      intro: 'Sawm is the fourth pillar of Islam. During Ramadan, Muslims fast from dawn (Fajr) to sunset (Maghrib), abstaining from food, drink, and other physical needs.',
      rules: [
        'Fast from Fajr (dawn) to Maghrib (sunset)',
        'Abstain from food, drink, and marital relations',
        'Make intention (niyyah) for fasting before Fajr',
        'Break fast with dates and water following the Sunnah',
        'Increase in worship, Quran recitation, and good deeds',
      ],
      exemptions: [
        'Travelers on long journeys',
        'Pregnant or nursing women',
        'Elderly who cannot fast',
        'Those who are ill',
        'Women during menstruation',
      ],
      steps: [
        { title: 'Suhoor', description: 'Wake up before Fajr to eat the pre-dawn meal. The Prophet (PBUH) said there is blessing in Suhoor.' },
        { title: 'Niyyah', description: 'Make intention to fast for the sake of Allah before Fajr begins.' },
        { title: 'Abstinence', description: 'Refrain from food, drink, and bad deeds throughout the day.' },
        { title: 'Increase Worship', description: 'Use the fasting hours for extra prayers, Quran reading, and dhikr.' },
        { title: 'Iftar', description: 'Break your fast at sunset with dates and water, then pray Maghrib.' },
        { title: 'Taraweeh', description: 'Perform the special night prayers during Ramadan after Isha.' },
      ],
    },
  },
  {
    id: 'zakat',
    icon: Wallet,
    title: 'Zakat (Charity)',
    arabicTitle: 'الزكاة',
    description: 'Obligatory charity purifies wealth and helps those in need.',
    color: 'from-amber-500 to-orange-600',
    content: {
      intro: 'Zakat is the third pillar of Islam. It is an obligatory form of charity that purifies wealth and helps the poor and needy. It is calculated as 2.5% of qualifying wealth.',
      requirements: [
        'Must possess wealth above the Nisab threshold',
        'Wealth must be held for one lunar year',
        'Calculated on savings, gold, silver, investments, and trade goods',
        'Rate is 2.5% of total qualifying wealth',
      ],
      recipients: [
        { category: 'Al-Fuqara', description: 'The poor who have less than the Nisab' },
        { category: 'Al-Masakin', description: 'The needy who have nothing' },
        { category: 'Zakat Collectors', description: 'Those employed to collect and distribute Zakat' },
        { category: 'New Muslims', description: 'Those who have recently embraced Islam' },
        { category: 'Slaves/Captives', description: 'To free those in bondage' },
        { category: 'Debtors', description: 'Those in debt who cannot pay' },
        { category: 'In the way of Allah', description: 'For Islamic causes and defense' },
        { category: 'Travelers', description: 'Stranded travelers in need' },
      ],
      steps: [
        { title: 'Calculate Wealth', description: 'Add up all Zakatable assets: savings, gold, silver, investments, and business inventory.' },
        { title: 'Check Nisab', description: 'Ensure your wealth exceeds the Nisab (minimum threshold) for one lunar year.' },
        { title: 'Calculate Zakat', description: 'Pay 2.5% of your total qualifying wealth as Zakat.' },
        { title: 'Distribute', description: 'Give to eligible recipients, prioritizing local needs and relatives.' },
      ],
    },
  },
  {
    id: 'hajj',
    icon: Plane,
    title: 'Hajj (Pilgrimage)',
    arabicTitle: 'الحج',
    description: 'The pilgrimage to Makkah is required once in a lifetime for those who are able.',
    color: 'from-blue-500 to-indigo-600',
    content: {
      intro: 'Hajj is the fifth pillar of Islam. It is a pilgrimage to the holy city of Makkah that every able Muslim must perform at least once in their lifetime. It takes place during the month of Dhul Hijjah.',
      requirements: [
        'Must be a Muslim adult of sound mind',
        'Must be physically able to perform the rituals',
        'Must have the financial means without hardship',
        'The journey must be safe',
        'Women should have a mahram (male guardian)',
      ],
      days: [
        { day: '8th Dhul Hijjah', name: 'Yawm al-Tarwiyah', description: 'Enter Ihram, go to Mina, pray five prayers' },
        { day: '9th Dhul Hijjah', name: 'Yawm Arafah', description: 'Stand at Arafat from noon to sunset - the most important day' },
        { day: '10th Dhul Hijjah', name: 'Yawm al-Nahr', description: 'Stone Jamarat, sacrifice, shave head, Tawaf and Sai' },
        { day: '11-13th Dhul Hijjah', name: 'Days of Tashreeq', description: 'Stay in Mina, stone all three Jamarat daily' },
      ],
      steps: [
        { title: 'Ihram', description: 'Enter the state of Ihram by wearing white garments, making intention, and reciting Talbiyah.' },
        { title: 'Tawaf al-Qudum', description: 'Perform seven circuits around the Kaaba upon arrival in Makkah.' },
        { title: 'Sai', description: 'Walk seven times between the hills of Safa and Marwah.' },
        { title: 'Day of Arafah', description: 'Stand at Arafat in prayer and supplication - the pinnacle of Hajj.' },
        { title: 'Muzdalifah', description: 'After sunset, proceed to Muzdalifah to spend the night and collect pebbles.' },
        { title: 'Stoning of Jamarat', description: 'Throw seven pebbles at the stone pillars representing Satan.' },
        { title: 'Sacrifice', description: 'Offer an animal sacrifice (Qurbani) following the Sunnah of Prophet Ibrahim.' },
        { title: 'Tawaf al-Ifadah', description: 'Perform the obligatory Tawaf after completing the main rituals.' },
      ],
    },
  },
];

interface WorshipSectionProps {
  worship: typeof worshipTypes[0];
  isExpanded: boolean;
  onToggle: () => void;
}

function WorshipSection({ worship, isExpanded, onToggle }: WorshipSectionProps) {
  const Icon = worship.icon;

  return (
    <div className="mb-6">
      <button
        onClick={onToggle}
        className="w-full islamic-card p-6 flex items-center justify-between hover:shadow-lg transition-shadow"
      >
        <div className="flex items-center gap-4">
          <div className={cn(
            'w-14 h-14 rounded-xl bg-gradient-to-br flex items-center justify-center',
            worship.color
          )}>
            <Icon className="w-7 h-7 text-white" />
          </div>
          <div className="text-left">
            <h3 className="text-xl font-semibold text-islamic-green-800">
              {worship.title}
            </h3>
            <p className="text-sm text-gray-500 mt-1">
              {worship.description}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="arabic-text text-2xl text-islamic-gold-600 hidden md:block">
            {worship.arabicTitle}
          </div>
          {isExpanded ? (
            <ChevronUp className="w-6 h-6 text-gray-400" />
          ) : (
            <ChevronDown className="w-6 h-6 text-gray-400" />
          )}
        </div>
      </button>

      {isExpanded && (
        <div className="mt-4 animate-in slide-in-from-top duration-300">
          {/* Introduction */}
          <div className="islamic-card p-6 mb-4">
            <p className="text-gray-700 leading-relaxed">
              {worship.content.intro}
            </p>
          </div>

          {/* Salah specific content */}
          {worship.id === 'salah' && (
            <div className="islamic-card p-6 mb-4">
              <h4 className="text-lg font-semibold text-islamic-green-800 mb-4">
                The Five Daily Prayers
              </h4>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {worship.content.prayers?.map((prayer, index) => (
                  <div key={index} className="p-4 bg-islamic-green-50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-islamic-green-800">{prayer.name}</span>
                      <span className="arabic-text text-islamic-gold-600">{prayer.arabic}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600 mb-1">
                      <Clock className="w-4 h-4" />
                      <span>{prayer.time}</span>
                    </div>
                    <p className="text-xs text-gray-500">{prayer.rakats}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Sawm specific content */}
          {worship.id === 'sawm' && worship.content.rules && (
            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div className="islamic-card p-6">
                <h4 className="text-lg font-semibold text-islamic-green-800 mb-4">
                  Rules of Fasting
                </h4>
                <ul className="space-y-2">
                  {worship.content.rules.map((rule, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-islamic-green-600 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{rule}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="islamic-card p-6">
                <h4 className="text-lg font-semibold text-islamic-green-800 mb-4">
                  Exemptions
                </h4>
                <ul className="space-y-2">
                  {worship.content.exemptions?.map((exemption, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <span className="w-5 h-5 rounded-full bg-islamic-gold-100 text-islamic-gold-600 flex items-center justify-center flex-shrink-0 mt-0.5 text-xs">
                        {index + 1}
                      </span>
                      <span className="text-gray-700">{exemption}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {/* Zakat specific content */}
          {worship.id === 'zakat' && worship.content.recipients && (
            <div className="islamic-card p-6 mb-4">
              <h4 className="text-lg font-semibold text-islamic-green-800 mb-4">
                Eight Categories of Zakat Recipients
              </h4>
              <div className="grid md:grid-cols-2 gap-3">
                {worship.content.recipients.map((recipient, index) => (
                  <div key={index} className="flex items-start gap-3 p-3 bg-islamic-green-50 rounded-lg">
                    <span className="w-6 h-6 rounded-full bg-islamic-green-600 text-white flex items-center justify-center flex-shrink-0 text-sm">
                      {index + 1}
                    </span>
                    <div>
                      <span className="font-medium text-islamic-green-800">{recipient.category}</span>
                      <p className="text-sm text-gray-600">{recipient.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Hajj specific content */}
          {worship.id === 'hajj' && worship.content.days && (
            <div className="islamic-card p-6 mb-4">
              <h4 className="text-lg font-semibold text-islamic-green-800 mb-4">
                Days of Hajj
              </h4>
              <div className="space-y-3">
                {worship.content.days.map((day, index) => (
                  <div key={index} className="flex items-start gap-4 p-4 bg-islamic-green-50 rounded-lg">
                    <div className="w-20 text-center flex-shrink-0">
                      <span className="text-sm font-medium text-islamic-gold-600">{day.day}</span>
                    </div>
                    <div>
                      <span className="font-medium text-islamic-green-800">{day.name}</span>
                      <p className="text-sm text-gray-600 mt-1">{day.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Steps */}
          <div className="islamic-card p-6">
            <h4 className="text-lg font-semibold text-islamic-green-800 mb-4">
              Step-by-Step Guide
            </h4>
            <div className="space-y-4">
              {worship.content.steps.map((step, index) => (
                <div key={index} className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-islamic-green-600 to-islamic-green-800 text-white flex items-center justify-center flex-shrink-0 font-medium">
                    {index + 1}
                  </div>
                  <div>
                    <h5 className="font-medium text-islamic-green-800">{step.title}</h5>
                    <p className="text-gray-600 text-sm mt-1">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function WorshipPage() {
  const [expandedSection, setExpandedSection] = useState<string | null>('salah');

  return (
    <IslamicLayout>
      {/* Hero Section */}
      <section className="relative py-16 overflow-hidden">
        <div className="absolute inset-0 islamic-gradient" />
        <div className="absolute inset-0 star-pattern opacity-20" />

        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full text-islamic-gold-300 text-sm mb-6">
            <HandHeart className="w-4 h-4" />
            <span>Acts of Worship</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Islamic Worship Guide
          </h1>

          <p className="text-xl text-white/80 max-w-2xl mx-auto">
            Learn about the essential acts of worship in Islam: Salah, Sawm, Zakat, and Hajj.
            Step-by-step guides to help you fulfill your religious obligations.
          </p>
        </div>
      </section>

      {/* Worship sections */}
      <section className="py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-islamic-green-800 mb-2">
              Pillars of Islam
            </h2>
            <p className="text-gray-600">
              Click on each section to learn about the pillars of Islam and how to practice them
            </p>
          </div>

          {worshipTypes.map((worship) => (
            <WorshipSection
              key={worship.id}
              worship={worship}
              isExpanded={expandedSection === worship.id}
              onToggle={() => setExpandedSection(expandedSection === worship.id ? null : worship.id)}
            />
          ))}
        </div>
      </section>

      <VoiceAssistant />
    </IslamicLayout>
  );
}
