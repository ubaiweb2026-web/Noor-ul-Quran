import { useState } from 'react';
import { BookText, BookOpen, Search, Star, User, Calendar } from 'lucide-react';
import IslamicLayout from '@/client/components/IslamicLayout';
import VoiceAssistant from '@/client/components/VoiceAssistant';
import { cn } from '@/client/lib/utils';

const bookCategories = [
  { id: 'all', label: 'All Books' },
  { id: 'hadith', label: 'Hadith Collections' },
  { id: 'fiqh', label: 'Islamic Jurisprudence' },
  { id: 'tafseer', label: 'Quran Tafseer' },
  { id: 'seerah', label: 'Prophet\'s Biography' },
  { id: 'aqeedah', label: 'Islamic Creed' },
];

const books = [
  {
    id: 1,
    category: 'hadith',
    title: 'Sahih Al-Bukhari',
    arabicTitle: 'صحيح البخاري',
    author: 'Imam Muhammad al-Bukhari',
    year: '846 CE',
    description: 'Considered the most authentic collection of Hadith. Contains approximately 7,275 hadith with repetitions, covering all aspects of Islamic life.',
    topics: ['Faith', 'Prayer', 'Fasting', 'Hajj', 'Business', 'Marriage'],
    hadithCount: 7275,
    featured: true,
    sampleHadith: {
      arabic: 'إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ',
      translation: 'Actions are judged by intentions.',
      narrator: 'Umar ibn al-Khattab (RA)',
    },
  },
  {
    id: 2,
    category: 'hadith',
    title: 'Sahih Muslim',
    arabicTitle: 'صحيح مسلم',
    author: 'Imam Muslim ibn al-Hajjaj',
    year: '875 CE',
    description: 'The second most authentic collection of Hadith. Known for its arrangement and lack of repetition.',
    topics: ['Faith', 'Purification', 'Prayer', 'Zakat', 'Pilgrimage'],
    hadithCount: 7500,
    featured: true,
    sampleHadith: {
      arabic: 'لاَ يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ',
      translation: 'None of you truly believes until he loves for his brother what he loves for himself.',
      narrator: 'Anas ibn Malik (RA)',
    },
  },
  {
    id: 3,
    category: 'hadith',
    title: 'Sunan Abu Dawud',
    arabicTitle: 'سنن أبي داود',
    author: 'Imam Abu Dawud',
    year: '889 CE',
    description: 'One of the six major hadith collections, focusing primarily on legal hadith.',
    topics: ['Purification', 'Prayer', 'Zakat', 'Fasting', 'Jihad', 'Manners'],
    hadithCount: 4800,
    featured: false,
  },
  {
    id: 4,
    category: 'hadith',
    title: 'Jami at-Tirmidhi',
    arabicTitle: 'جامع الترمذي',
    author: 'Imam at-Tirmidhi',
    year: '892 CE',
    description: 'Known for categorizing hadith by their level of authenticity and including jurisprudential rulings.',
    topics: ['Faith', 'Prayer', 'Zakat', 'Hajj', 'Virtues', 'Supplications'],
    hadithCount: 3956,
    featured: false,
  },
  {
    id: 5,
    category: 'hadith',
    title: 'Riyad as-Salihin',
    arabicTitle: 'رياض الصالحين',
    author: 'Imam an-Nawawi',
    year: '1277 CE',
    description: 'A compilation of verses from the Quran and hadith, organized by ethical and spiritual topics.',
    topics: ['Sincerity', 'Patience', 'Fear of Allah', 'Hope', 'Repentance', 'Good Character'],
    hadithCount: 1896,
    featured: true,
    sampleHadith: {
      arabic: 'الدِّينُ النَّصِيحَةُ',
      translation: 'Religion is sincerity/sincere advice.',
      narrator: 'Tamim ad-Dari (RA)',
    },
  },
  {
    id: 6,
    category: 'tafseer',
    title: 'Tafsir Ibn Kathir',
    arabicTitle: 'تفسير ابن كثير',
    author: 'Ibn Kathir',
    year: '1373 CE',
    description: 'One of the most popular and comprehensive Quran commentaries, known for explaining verses using other verses and hadith.',
    topics: ['Quran Explanation', 'Historical Context', 'Linguistic Analysis'],
    featured: true,
  },
  {
    id: 7,
    category: 'tafseer',
    title: 'Tafsir al-Jalalayn',
    arabicTitle: 'تفسير الجلالين',
    author: 'Jalal ad-Din al-Mahalli & Jalal ad-Din as-Suyuti',
    year: '1505 CE',
    description: 'A concise classical tafsir of the Quran, popular for its brevity and clarity.',
    topics: ['Concise Interpretation', 'Arabic Grammar', 'Basic Understanding'],
    featured: false,
  },
  {
    id: 8,
    category: 'seerah',
    title: 'Ar-Raheeq Al-Makhtum',
    arabicTitle: 'الرحيق المختوم',
    author: 'Safi-ur-Rahman al-Mubarakpuri',
    year: '1976 CE',
    description: 'The Sealed Nectar - An award-winning biography of Prophet Muhammad (PBUH), known for its accuracy and readability.',
    topics: ['Prophet\'s Life', 'Early Islam', 'Battles', 'Companions'],
    featured: true,
  },
  {
    id: 9,
    category: 'seerah',
    title: 'Sirat Ibn Hisham',
    arabicTitle: 'سيرة ابن هشام',
    author: 'Ibn Hisham',
    year: '833 CE',
    description: 'One of the earliest and most authentic biographies of Prophet Muhammad (PBUH).',
    topics: ['Prophet\'s Life', 'Pre-Islamic Arabia', 'Early Revelations'],
    featured: false,
  },
  {
    id: 10,
    category: 'fiqh',
    title: 'Fiqh us-Sunnah',
    arabicTitle: 'فقه السنة',
    author: 'Sayyid Sabiq',
    year: '1945 CE',
    description: 'A comprehensive book on Islamic jurisprudence based on authentic hadith, accessible to common readers.',
    topics: ['Purification', 'Prayer', 'Fasting', 'Zakat', 'Hajj', 'Marriage'],
    featured: true,
  },
  {
    id: 11,
    category: 'aqeedah',
    title: 'Kitab at-Tawhid',
    arabicTitle: 'كتاب التوحيد',
    author: 'Muhammad ibn Abd al-Wahhab',
    year: '1751 CE',
    description: 'A foundational text on Islamic monotheism, explaining the concept of Tawhid with Quranic verses and hadith.',
    topics: ['Monotheism', 'Shirk', 'Worship', 'Supplication'],
    featured: false,
  },
  {
    id: 12,
    category: 'aqeedah',
    title: 'Al-Aqidah al-Wasitiyyah',
    arabicTitle: 'العقيدة الواسطية',
    author: 'Ibn Taymiyyah',
    year: '1306 CE',
    description: 'A classical text on Islamic creed, outlining the beliefs of Ahl as-Sunnah wal-Jama\'ah.',
    topics: ['Names of Allah', 'Attributes of Allah', 'Faith', 'Day of Judgment'],
    featured: false,
  },
];

interface BookCardProps {
  book: typeof books[0];
  onClick: () => void;
}

function BookCard({ book, onClick }: BookCardProps) {
  return (
    <button
      onClick={onClick}
      className="w-full islamic-card p-6 text-left hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
    >
      <div className="flex items-start gap-4">
        {/* Book icon */}
        <div className={cn(
          'w-16 h-20 rounded-lg flex items-center justify-center flex-shrink-0',
          book.featured
            ? 'bg-gradient-to-br from-islamic-gold-400 to-islamic-gold-600'
            : 'bg-gradient-to-br from-islamic-green-600 to-islamic-green-800'
        )}>
          <BookOpen className="w-8 h-8 text-white" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h3 className="text-lg font-semibold text-islamic-green-800 mb-1">
                {book.title}
              </h3>
              <p className="arabic-text text-islamic-gold-600">
                {book.arabicTitle}
              </p>
            </div>
            {book.featured && (
              <div className="flex items-center gap-1 px-2 py-1 bg-islamic-gold-100 rounded-full">
                <Star className="w-3 h-3 text-islamic-gold-600 fill-current" />
                <span className="text-xs text-islamic-gold-700">Featured</span>
              </div>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-4 mt-3 text-sm text-gray-500">
            <div className="flex items-center gap-1">
              <User className="w-4 h-4" />
              <span>{book.author}</span>
            </div>
            {book.year && (
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                <span>{book.year}</span>
              </div>
            )}
          </div>

          <p className="text-gray-600 text-sm mt-3 line-clamp-2">
            {book.description}
          </p>

          {book.topics && (
            <div className="flex flex-wrap gap-2 mt-3">
              {book.topics.slice(0, 3).map((topic, index) => (
                <span
                  key={index}
                  className="px-2 py-1 bg-islamic-green-50 text-islamic-green-700 text-xs rounded-full"
                >
                  {topic}
                </span>
              ))}
              {book.topics.length > 3 && (
                <span className="px-2 py-1 bg-gray-100 text-gray-500 text-xs rounded-full">
                  +{book.topics.length - 3} more
                </span>
              )}
            </div>
          )}
        </div>
      </div>
    </button>
  );
}

interface BookDetailModalProps {
  book: typeof books[0] | null;
  onClose: () => void;
}

function BookDetailModal({ book, onClose }: BookDetailModalProps) {
  if (!book) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-gradient-to-r from-islamic-green-700 to-islamic-green-800 text-white p-6 rounded-t-2xl">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center"
          >
            <span className="text-lg">&times;</span>
          </button>

          <div className="arabic-text text-2xl text-islamic-gold-300 mb-2">
            {book.arabicTitle}
          </div>
          <h2 className="text-2xl font-bold">{book.title}</h2>
          <p className="text-white/80 mt-2">{book.author}</p>
        </div>

        {/* Content */}
        <div className="p-6">
          <p className="text-gray-700 leading-relaxed mb-6">
            {book.description}
          </p>

          {book.hadithCount && (
            <div className="mb-6 p-4 bg-islamic-green-50 rounded-lg">
              <p className="text-islamic-green-800">
                <span className="font-semibold">{book.hadithCount.toLocaleString()}</span> hadith collected
              </p>
            </div>
          )}

          {book.topics && (
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-islamic-green-800 mb-3">Topics Covered</h3>
              <div className="flex flex-wrap gap-2">
                {book.topics.map((topic, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-islamic-green-100 text-islamic-green-700 text-sm rounded-full"
                  >
                    {topic}
                  </span>
                ))}
              </div>
            </div>
          )}

          {book.sampleHadith && (
            <div className="p-6 bg-islamic-gold-50 rounded-xl border border-islamic-gold-100">
              <h3 className="text-lg font-semibold text-islamic-green-800 mb-4">Sample Hadith</h3>
              <div className="arabic-text text-xl text-islamic-green-900 mb-3 text-right">
                {book.sampleHadith.arabic}
              </div>
              <p className="text-gray-700 italic mb-2">
                "{book.sampleHadith.translation}"
              </p>
              <p className="text-sm text-islamic-gold-600">
                Narrated by: {book.sampleHadith.narrator}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function BooksPage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBook, setSelectedBook] = useState<typeof books[0] | null>(null);

  const filteredBooks = books.filter((book) => {
    const matchesCategory = selectedCategory === 'all' || book.category === selectedCategory;
    const matchesSearch = searchQuery === '' ||
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <IslamicLayout>
      {/* Hero Section */}
      <section className="relative py-16 overflow-hidden">
        <div className="absolute inset-0 islamic-gradient" />
        <div className="absolute inset-0 star-pattern opacity-20" />

        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full text-islamic-gold-300 text-sm mb-6">
            <BookText className="w-4 h-4" />
            <span>Islamic Library</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Religious Books
          </h1>

          <p className="text-xl text-white/80 max-w-2xl mx-auto mb-8">
            Explore authentic Islamic literature including Hadith collections,
            Quran Tafseer, Prophet's biography, and books on Islamic jurisprudence.
          </p>

          {/* Search */}
          <div className="max-w-md mx-auto relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search books or authors..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-lg bg-white text-gray-800 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-islamic-gold-400"
            />
          </div>
        </div>
      </section>

      {/* Category tabs */}
      <section className="sticky top-[65px] z-40 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex overflow-x-auto py-3 gap-2 scrollbar-hide">
            {bookCategories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={cn(
                  'px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all',
                  selectedCategory === category.id
                    ? 'bg-islamic-green-700 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                )}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Books list */}
      <section className="py-12 px-4">
        <div className="max-w-4xl mx-auto">
          {filteredBooks.length > 0 ? (
            <div className="grid gap-6">
              {filteredBooks.map((book) => (
                <BookCard
                  key={book.id}
                  book={book}
                  onClick={() => setSelectedBook(book)}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <BookText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No books found matching your search.</p>
            </div>
          )}
        </div>
      </section>

      {/* Book detail modal */}
      <BookDetailModal book={selectedBook} onClose={() => setSelectedBook(null)} />

      <VoiceAssistant />
    </IslamicLayout>
  );
}
