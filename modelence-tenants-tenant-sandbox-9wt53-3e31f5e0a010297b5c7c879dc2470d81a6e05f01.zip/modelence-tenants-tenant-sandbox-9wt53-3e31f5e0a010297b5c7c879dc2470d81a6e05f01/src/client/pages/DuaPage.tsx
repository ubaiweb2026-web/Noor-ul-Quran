import { useState } from 'react';
import { Moon, Play, Pause, Sun, Coffee, Utensils, Car, Bed, Heart, Search } from 'lucide-react';
import IslamicLayout from '@/client/components/IslamicLayout';
import VoiceAssistant from '@/client/components/VoiceAssistant';
import { cn } from '@/client/lib/utils';

const duaCategories = [
  { id: 'morning', label: 'Morning', icon: Sun },
  { id: 'evening', label: 'Evening', icon: Moon },
  { id: 'food', label: 'Food & Drink', icon: Utensils },
  { id: 'travel', label: 'Travel', icon: Car },
  { id: 'sleep', label: 'Sleep', icon: Bed },
  { id: 'daily', label: 'Daily Life', icon: Coffee },
  { id: 'protection', label: 'Protection', icon: Heart },
];

const duas = [
  {
    id: 1,
    category: 'morning',
    title: 'Morning Dhikr',
    arabic: 'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ',
    transliteration: 'Asbahna wa asbahal-mulku lillah, walhamdu lillah, la ilaha illallahu wahdahu la shareeka lah',
    translation: 'We have reached the morning and at this very time unto Allah belongs all sovereignty. All praise is due to Allah. None has the right to be worshipped except Allah, alone, without partner.',
    reference: 'Abu Dawud 4:317',
  },
  {
    id: 2,
    category: 'morning',
    title: 'Master of Morning Dua',
    arabic: 'اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ',
    transliteration: 'Allahumma bika asbahna, wa bika amsayna, wa bika nahya, wa bika namootu, wa ilaykan-nushoor',
    translation: 'O Allah, by Your leave we have reached the morning and by Your leave we have reached the evening. By Your leave we live and die and unto You is our resurrection.',
    reference: 'Tirmidhi 5:466',
  },
  {
    id: 3,
    category: 'evening',
    title: 'Evening Dhikr',
    arabic: 'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ',
    transliteration: 'Amsayna wa amsal-mulku lillah, walhamdu lillah, la ilaha illallahu wahdahu la shareeka lah',
    translation: 'We have reached the evening and at this very time unto Allah belongs all sovereignty. All praise is due to Allah. None has the right to be worshipped except Allah, alone, without partner.',
    reference: 'Abu Dawud 4:317',
  },
  {
    id: 4,
    category: 'evening',
    title: 'Protection at Night',
    arabic: 'اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنْ شَرِّ مَا عَمِلْتُ، وَمِنْ شَرِّ مَا لَمْ أَعْمَلْ',
    transliteration: 'Allahumma inni a\'udhu bika min sharri ma \'amiltu, wa min sharri ma lam a\'mal',
    translation: 'O Allah, I seek refuge in You from the evil of what I have done and from the evil of what I have not done.',
    reference: 'Muslim 4:2085',
  },
  {
    id: 5,
    category: 'food',
    title: 'Before Eating',
    arabic: 'بِسْمِ اللَّهِ',
    transliteration: 'Bismillah',
    translation: 'In the name of Allah.',
    reference: 'Abu Dawud 3:1615',
  },
  {
    id: 6,
    category: 'food',
    title: 'After Eating',
    arabic: 'الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنِي هَذَا، وَرَزَقَنِيهِ، مِنْ غَيْرِ حَوْلٍ مِنِّي وَلاَ قُوَّةٍ',
    transliteration: 'Alhamdu lillahil-ladhi at\'amani hadha, wa razaqanihi, min ghayri hawlin minni wa la quwwah',
    translation: 'All praise is due to Allah who has fed me this and provided it for me without any might or power from myself.',
    reference: 'Abu Dawud, Tirmidhi',
  },
  {
    id: 7,
    category: 'food',
    title: 'Before Drinking Water',
    arabic: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
    transliteration: 'Bismillahir Rahmanir Raheem',
    translation: 'In the name of Allah, the Most Gracious, the Most Merciful.',
    reference: 'Sunnah of the Prophet',
  },
  {
    id: 8,
    category: 'travel',
    title: 'When Starting a Journey',
    arabic: 'سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ',
    transliteration: 'Subhanal-ladhi sakhkhara lana hadha wa ma kunna lahu muqrinin. Wa inna ila Rabbina lamunqalibun',
    translation: 'Glory to Him who has subjected this to us, and we could never have accomplished it ourselves. And to our Lord is our final return.',
    reference: 'Quran 43:13-14',
  },
  {
    id: 9,
    category: 'travel',
    title: 'Returning from Travel',
    arabic: 'آيِبُونَ، تَائِبُونَ، عَابِدُونَ، لِرَبِّنَا حَامِدُونَ',
    transliteration: 'Ayibuna, ta\'ibuna, \'abiduna, li Rabbina hamidun',
    translation: 'We return repentant, worshipping, and praising our Lord.',
    reference: 'Bukhari 7:210',
  },
  {
    id: 10,
    category: 'sleep',
    title: 'Before Sleeping',
    arabic: 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا',
    transliteration: 'Bismika Allahumma amootu wa ahya',
    translation: 'In Your name O Allah, I die and I live.',
    reference: 'Bukhari 7:5953',
  },
  {
    id: 11,
    category: 'sleep',
    title: 'Upon Waking Up',
    arabic: 'الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ',
    transliteration: 'Alhamdu lillahil-ladhi ahyana ba\'da ma amatana wa ilayhin-nushur',
    translation: 'All praise is due to Allah who gave us life after having taken it from us and unto Him is the resurrection.',
    reference: 'Bukhari 7:5954',
  },
  {
    id: 12,
    category: 'daily',
    title: 'Entering the Home',
    arabic: 'اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ الْمَوْلِجِ وَخَيْرَ الْمَخْرَجِ، بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا، وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا',
    transliteration: 'Allahumma inni as\'aluka khayral-mawliji wa khayral-makhraji, bismillahi walajna, wa bismillahi kharajna, wa \'alallahi Rabbina tawakkalna',
    translation: 'O Allah, I ask You for the best entrance and the best exit. In the name of Allah we enter and in the name of Allah we leave, and upon Allah our Lord we depend.',
    reference: 'Abu Dawud 4:325',
  },
  {
    id: 13,
    category: 'daily',
    title: 'Leaving the Home',
    arabic: 'بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، وَلاَ حَوْلَ وَلاَ قُوَّةَ إِلاَّ بِاللَّهِ',
    transliteration: 'Bismillah, tawakkaltu \'alallah, wa la hawla wa la quwwata illa billah',
    translation: 'In the name of Allah, I place my trust in Allah, and there is no might nor power except with Allah.',
    reference: 'Abu Dawud 4:325',
  },
  {
    id: 14,
    category: 'protection',
    title: 'Seeking Refuge',
    arabic: 'أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ',
    transliteration: 'A\'udhu bikalimatillahit-tammati min sharri ma khalaq',
    translation: 'I seek refuge in the perfect words of Allah from the evil of what He has created.',
    reference: 'Muslim 4:2080',
  },
  {
    id: 15,
    category: 'protection',
    title: 'Morning/Evening Protection',
    arabic: 'بِسْمِ اللَّهِ الَّذِي لاَ يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الأَرْضِ وَلاَ فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ',
    transliteration: 'Bismillahil-ladhi la yadurru ma\'asmihi shay\'un fil-ardi wa la fis-sama\'i wa huwas-Sami\'ul-\'Alim',
    translation: 'In the name of Allah with whose name nothing is harmed on earth nor in the heavens and He is the All-Hearing, the All-Knowing.',
    reference: 'Abu Dawud 4:323',
  },
];

interface DuaCardProps {
  dua: typeof duas[0];
  isPlaying: boolean;
  onPlay: () => void;
}

function DuaCard({ dua, isPlaying, onPlay }: DuaCardProps) {
  const handlePlay = () => {
    if ('speechSynthesis' in window) {
      const synth = window.speechSynthesis;
      if (isPlaying) {
        synth.cancel();
      } else {
        const utterance = new SpeechSynthesisUtterance(dua.transliteration);
        utterance.rate = 0.7;
        synth.speak(utterance);
      }
    }
    onPlay();
  };

  return (
    <div className="islamic-card p-6">
      <div className="flex items-start justify-between mb-4">
        <h3 className="text-lg font-semibold text-islamic-green-800">
          {dua.title}
        </h3>
        <button
          onClick={handlePlay}
          className={cn(
            'w-10 h-10 rounded-full flex items-center justify-center transition-all',
            isPlaying
              ? 'bg-islamic-gold-500 text-islamic-green-900'
              : 'bg-islamic-green-100 text-islamic-green-700 hover:bg-islamic-green-200'
          )}
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
        </button>
      </div>

      {/* Arabic text */}
      <div className="arabic-text text-2xl text-islamic-green-900 mb-4 text-right leading-loose bg-islamic-green-50 p-4 rounded-lg">
        {dua.arabic}
      </div>

      {/* Transliteration */}
      <p className="text-gray-500 italic mb-3">
        {dua.transliteration}
      </p>

      {/* Translation */}
      <p className="text-gray-700 mb-3">
        {dua.translation}
      </p>

      {/* Reference */}
      <p className="text-sm text-islamic-gold-600">
        Reference: {dua.reference}
      </p>
    </div>
  );
}

export default function DuaPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('morning');
  const [searchQuery, setSearchQuery] = useState('');
  const [playingDua, setPlayingDua] = useState<number | null>(null);

  const filteredDuas = duas.filter((dua) => {
    const matchesCategory = selectedCategory === 'all' || dua.category === selectedCategory;
    const matchesSearch = searchQuery === '' ||
      dua.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dua.translation.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <IslamicLayout>
      {/* Hero Section */}
      <section className="relative py-16 overflow-hidden">
        <div className="absolute inset-0 islamic-gradient" />
        <div className="absolute inset-0 star-pattern opacity-20" />

        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full text-islamic-gold-300 text-sm mb-6">
            <Moon className="w-4 h-4" />
            <span>Supplications</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Daily Duas
          </h1>

          <p className="text-xl text-white/80 max-w-2xl mx-auto mb-8">
            Essential supplications from the Quran and Sunnah for every moment of your day.
            Listen to the Arabic pronunciation and learn their meanings.
          </p>

          {/* Search */}
          <div className="max-w-md mx-auto relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search duas..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-lg bg-white text-gray-800 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-islamic-gold-400"
            />
          </div>
        </div>
      </section>

      {/* Category tabs */}
      <section className="sticky top-[65px] z-40 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex overflow-x-auto py-3 gap-2 scrollbar-hide">
            {duaCategories.map((category) => {
              const Icon = category.icon;
              return (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={cn(
                    'flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all',
                    selectedCategory === category.id
                      ? 'bg-islamic-green-700 text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  )}
                >
                  <Icon className="w-4 h-4" />
                  <span>{category.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Duas list */}
      <section className="py-12 px-4">
        <div className="max-w-4xl mx-auto">
          {filteredDuas.length > 0 ? (
            <div className="grid gap-6">
              {filteredDuas.map((dua) => (
                <DuaCard
                  key={dua.id}
                  dua={dua}
                  isPlaying={playingDua === dua.id}
                  onPlay={() => setPlayingDua(playingDua === dua.id ? null : dua.id)}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Moon className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No duas found matching your search.</p>
            </div>
          )}
        </div>
      </section>

      <VoiceAssistant />
    </IslamicLayout>
  );
}
