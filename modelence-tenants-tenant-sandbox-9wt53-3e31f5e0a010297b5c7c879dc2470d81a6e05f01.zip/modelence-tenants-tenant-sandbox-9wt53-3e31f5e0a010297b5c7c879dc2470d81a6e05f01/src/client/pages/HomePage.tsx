import { Link } from 'react-router-dom';
import {
  BookOpen,
  Info,
  HandHeart,
  Moon,
  BookText,
  History,
  ArrowRight,
  Sparkles,
  Headphones,
  Play,
  Volume2,
  Languages,
} from 'lucide-react';
import IslamicLayout from '@/client/components/IslamicLayout';
import VoiceAssistant from '@/client/components/VoiceAssistant';

const featuredReciters = [
  {
    id: 'abdurrahman_alsudais',
    name: 'Abdul Rahman Al-Sudais',
    arabicName: 'عبدالرحمن السديس',
    title: 'Imam of Masjid al-Haram',
    image: '/images/reciters/sudais.jpg',
  },
  {
    id: 'mishary_alafasy',
    name: 'Mishary Rashid Alafasy',
    arabicName: 'مشاري راشد العفاسي',
    title: 'Kuwaiti Quran Reciter',
    image: '/images/reciters/alafasy.jpg',
  },
  {
    id: 'maher_almuaiqly',
    name: 'Maher Al-Muaiqly',
    arabicName: 'ماهر المعيقلي',
    title: 'Imam of Masjid al-Haram',
    image: '/images/reciters/muaiqly.jpg',
  },
];

const quickLinks = [
  {
    path: '/quran',
    label: 'Holy Quran',
    description: 'Read, listen, and understand the divine words',
    icon: BookOpen,
    color: 'from-emerald-500 to-green-600',
  },
  {
    path: '/worship',
    label: 'Worship Guide',
    description: 'Learn Salah, fasting, zakat, and Hajj',
    icon: HandHeart,
    color: 'from-blue-500 to-indigo-600',
  },
  {
    path: '/dua',
    label: 'Daily Duas',
    description: 'Essential supplications for daily life',
    icon: Moon,
    color: 'from-purple-500 to-violet-600',
  },
  {
    path: '/books',
    label: 'Islamic Books',
    description: 'Hadith collections and Islamic teachings',
    icon: BookText,
    color: 'from-amber-500 to-orange-600',
  },
  {
    path: '/history',
    label: 'Islamic History',
    description: 'Important events and battles of Islam',
    icon: History,
    color: 'from-rose-500 to-red-600',
  },
  {
    path: '/about',
    label: 'About Us',
    description: 'Learn about our mission and vision',
    icon: Info,
    color: 'from-teal-500 to-cyan-600',
  },
];

function HeroSection() {
  return (
    <section className="relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 islamic-gradient" />
      <div className="absolute inset-0 star-pattern opacity-30" />

      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-islamic-gold-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-islamic-gold-500/10 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 py-16 md:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full text-islamic-gold-300 text-sm mb-6">
              <Sparkles className="w-4 h-4" />
              <span>Welcome to the Light of Knowledge</span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
              Noor-ul-Quran
            </h1>

            <p className="text-lg md:text-xl text-white/80 mb-8 max-w-xl mx-auto lg:mx-0">
              Embark on a journey of spiritual enlightenment through the Holy Quran,
              authentic teachings, and the beautiful traditions of Islam.
            </p>

            {/* Inspirational verse */}
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 mb-8 border border-white/20">
              <div className="arabic-text text-2xl md:text-3xl text-islamic-gold-300 mb-3">
                اللَّهُ نُورُ السَّمَاوَاتِ وَالْأَرْضِ
              </div>
              <p className="text-white/90 italic">
                "Allah is the Light of the heavens and the earth"
              </p>
              <p className="text-islamic-gold-400 text-sm mt-2">
                Surah An-Nur (24:35)
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link
                to="/quran"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-islamic-gold-500 text-[#0f5e3b] font-semibold rounded-lg hover:bg-islamic-gold-400 transition-colors"
              >
                <Headphones className="w-5 h-5" />
                Listen to Quran
              </Link>
              <Link
                to="/quran"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 border-2 border-white/30 text-white font-semibold rounded-lg hover:bg-white/10 transition-colors"
              >
                <BookOpen className="w-5 h-5" />
                Read Quran
              </Link>
            </div>
          </div>

          {/* Right content - Quran on Rehal illustration */}
          <div className="flex justify-center">
            <div className="relative">
              {/* Glow effect */}
              <div className="absolute inset-0 bg-islamic-gold-400/30 rounded-full blur-3xl animate-pulse" />

              {/* Rehal (Book stand) */}
              <div className="relative animate-float">
                {/* Light rays */}
                <div className="absolute inset-0 flex items-center justify-center">
                  {[...Array(8)].map((_, i) => (
                    <div
                      key={i}
                      className="absolute w-1 h-32 bg-gradient-to-t from-islamic-gold-400/0 via-islamic-gold-400/30 to-islamic-gold-400/0"
                      style={{
                        transform: `rotate(${i * 45}deg)`,
                        transformOrigin: 'center 80px',
                      }}
                    />
                  ))}
                </div>

                {/* Quran book */}
                <div className="relative z-10 w-64 h-80 bg-gradient-to-br from-islamic-green-700 to-islamic-green-900 rounded-lg shadow-2xl border-4 border-islamic-gold-500 soft-glow">
                  {/* Book spine detail */}
                  <div className="absolute left-0 top-0 bottom-0 w-4 bg-gradient-to-r from-islamic-gold-600 to-islamic-gold-500" />

                  {/* Book cover design */}
                  <div className="flex flex-col items-center justify-center h-full px-8">
                    {/* Decorative frame */}
                    <div className="absolute inset-8 border-2 border-islamic-gold-400/50 rounded-lg" />
                    <div className="absolute inset-10 border border-islamic-gold-400/30 rounded-lg" />

                    {/* Arabic title */}
                    <div className="arabic-text text-3xl text-islamic-gold-400 mb-2">
                      القرآن الكريم
                    </div>
                    <div className="w-16 h-0.5 bg-islamic-gold-400/50 mb-4" />
                    <p className="text-islamic-gold-300 text-sm">The Holy Quran</p>

                    {/* Star decoration */}
                    <div className="absolute bottom-12 w-8 h-8 text-islamic-gold-400">
                      <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2l2.4 7.4h7.6l-6 4.6 2.3 7-6.3-4.6-6.3 4.6 2.3-7-6-4.6h7.6z" />
                      </svg>
                    </div>
                  </div>
                </div>

                {/* Wooden Rehal stand */}
                <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 w-48">
                  <svg viewBox="0 0 200 60" className="w-full h-auto">
                    {/* Left leg */}
                    <path
                      d="M30,0 L70,50 L60,55 L25,5 Z"
                      fill="url(#wood-gradient)"
                      stroke="#5d4037"
                      strokeWidth="1"
                    />
                    {/* Right leg */}
                    <path
                      d="M170,0 L130,50 L140,55 L175,5 Z"
                      fill="url(#wood-gradient)"
                      stroke="#5d4037"
                      strokeWidth="1"
                    />
                    {/* Cross bar */}
                    <path
                      d="M60,40 L140,40 L145,50 L55,50 Z"
                      fill="url(#wood-gradient-dark)"
                      stroke="#5d4037"
                      strokeWidth="1"
                    />
                    <defs>
                      <linearGradient id="wood-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#a1887f" />
                        <stop offset="50%" stopColor="#8d6e63" />
                        <stop offset="100%" stopColor="#6d4c41" />
                      </linearGradient>
                      <linearGradient id="wood-gradient-dark" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#6d4c41" />
                        <stop offset="100%" stopColor="#5d4037" />
                      </linearGradient>
                    </defs>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom decorative border */}
      <div className="h-2 gold-gradient" />
    </section>
  );
}

function QuickLinksSection() {
  return (
    <section className="py-16 md:py-24 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-islamic-green-800 mb-4">
            Explore Islamic Knowledge
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Navigate through our comprehensive collection of Islamic resources,
            designed to help you grow spiritually and intellectually.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quickLinks.map((link) => {
            const Icon = link.icon;
            return (
              <Link
                key={link.path}
                to={link.path}
                className="group islamic-card p-6 hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
              >
                <div
                  className={`w-14 h-14 rounded-xl bg-gradient-to-br ${link.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}
                >
                  <Icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-islamic-green-800 mb-2 group-hover:text-islamic-gold-600 transition-colors">
                  {link.label}
                </h3>
                <p className="text-gray-600 text-sm">{link.description}</p>
                <div className="mt-4 flex items-center text-islamic-gold-600 text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                  <span>Explore</span>
                  <ArrowRight className="w-4 h-4 ml-1" />
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function FeaturedRecitersSection() {
  return (
    <section className="py-16 md:py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0f5e3b]/10 rounded-full text-[#0f5e3b] text-sm mb-4">
            <Headphones className="w-4 h-4" />
            <span>High-Quality Recitations</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-[#0f5e3b] mb-4">
            World-Renowned Reciters
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Listen to beautiful Quran recitations from the most famous and respected
            reciters in the Islamic world.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {featuredReciters.map((reciter) => (
            <Link
              key={reciter.id}
              to="/quran"
              className="group bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              {/* Reciter visual */}
              <div className="h-40 bg-gradient-to-br from-[#0f5e3b] to-[#0a3d27] relative overflow-hidden">
                <div className="absolute inset-0 star-pattern opacity-20" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-24 h-24 rounded-full bg-islamic-gold-500/20 flex items-center justify-center border-2 border-islamic-gold-400/50">
                    <Volume2 className="w-10 h-10 text-islamic-gold-400" />
                  </div>
                </div>
                {/* Play button overlay */}
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                  <div className="w-14 h-14 rounded-full bg-islamic-gold-500 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity transform scale-90 group-hover:scale-100">
                    <Play className="w-7 h-7 text-[#0f5e3b] ml-1" fill="currentColor" />
                  </div>
                </div>
              </div>

              {/* Reciter info */}
              <div className="p-6 text-center">
                <div className="arabic-text text-xl text-[#0f5e3b] mb-2">
                  {reciter.arabicName}
                </div>
                <h3 className="text-lg font-semibold text-gray-800 mb-1">
                  {reciter.name}
                </h3>
                <p className="text-sm text-gray-500">{reciter.title}</p>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center mt-10">
          <Link
            to="/quran"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#0f5e3b] text-white font-semibold rounded-lg hover:bg-[#0a4d30] transition-colors"
          >
            <Headphones className="w-5 h-5" />
            Browse All 114 Surahs
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </div>
    </section>
  );
}

function AudioFeaturesSection() {
  const features = [
    {
      icon: Headphones,
      title: 'Premium Audio Quality',
      description: 'Crystal clear 128kbps audio streaming for an immersive listening experience.',
    },
    {
      icon: Languages,
      title: 'Translations',
      description: 'English and Urdu translations available for every ayah.',
    },
    {
      icon: Volume2,
      title: 'Multiple Reciters',
      description: 'Choose from 5 world-renowned reciters including Al-Sudais and Mishary Alafasy.',
    },
    {
      icon: BookOpen,
      title: 'Ayah Highlighting',
      description: 'Follow along with synchronized ayah highlighting during recitation.',
    },
  ];

  return (
    <section className="py-16 bg-[#0f5e3b] relative overflow-hidden">
      <div className="absolute inset-0 star-pattern opacity-10" />

      <div className="relative max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Advanced Quran Listening Features
          </h2>
          <p className="text-white/80 max-w-2xl mx-auto">
            Experience the Holy Quran like never before with our modern audio player
            and comprehensive features.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20 hover:bg-white/20 transition-colors"
              >
                <div className="w-12 h-12 rounded-lg bg-islamic-gold-500 flex items-center justify-center mb-4">
                  <Icon className="w-6 h-6 text-[#0f5e3b]" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                <p className="text-white/70 text-sm">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function DailyVerseSection() {
  return (
    <section className="py-16 bg-gradient-to-br from-[#0a3d27] to-[#0f5e3b] relative overflow-hidden">
      <div className="absolute inset-0 star-pattern opacity-20" />

      <div className="relative max-w-4xl mx-auto px-4 text-center">
        <h2 className="text-2xl md:text-3xl font-bold text-islamic-gold-400 mb-8">
          Verse of Reflection
        </h2>

        <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 md:p-12 border border-white/20">
          <div className="arabic-text text-2xl md:text-4xl text-white mb-6 leading-relaxed">
            إِنَّ اللَّهَ مَعَ الصَّابِرِينَ
          </div>

          <p className="text-xl md:text-2xl text-white/90 italic mb-4">
            "Indeed, Allah is with the patient."
          </p>

          <p className="text-islamic-gold-400">
            Surah Al-Baqarah (2:153)
          </p>
        </div>
      </div>
    </section>
  );
}

export default function HomePage() {
  return (
    <IslamicLayout>
      <HeroSection />
      <FeaturedRecitersSection />
      <AudioFeaturesSection />
      <QuickLinksSection />
      <DailyVerseSection />
      <VoiceAssistant />
    </IslamicLayout>
  );
}
