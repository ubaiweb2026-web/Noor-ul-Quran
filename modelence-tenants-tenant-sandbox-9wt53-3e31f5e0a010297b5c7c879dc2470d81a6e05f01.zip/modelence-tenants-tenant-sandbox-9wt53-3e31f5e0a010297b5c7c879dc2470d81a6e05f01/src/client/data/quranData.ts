// Complete list of all 114 Surahs with metadata
export interface Surah {
  id: number;
  name: string;
  arabicName: string;
  englishName: string;
  meaning: string;
  verses: number;
  type: 'Meccan' | 'Medinan';
  order: number; // Revelation order
}

export interface Reciter {
  id: string;
  name: string;
  arabicName: string;
  style: string;
  audioBaseUrl: string;
}

export interface Ayah {
  number: number;
  arabic: string;
  translation: string;
  translationUrdu?: string;
  transliteration?: string;
}

// Famous Quran Reciters with CDN audio sources
export const reciters: Reciter[] = [
  {
    id: 'abdurrahman_alsudais',
    name: 'Abdul Rahman Al-Sudais',
    arabicName: 'عبدالرحمن السديس',
    style: 'Imam of Masjid al-Haram',
    audioBaseUrl: 'https://cdn.islamic.network/quran/audio/128/ar.abdurrahmaansudais',
  },
  {
    id: 'mishary_alafasy',
    name: 'Mishary Rashid Alafasy',
    arabicName: 'مشاري راشد العفاسي',
    style: 'Melodious Kuwaiti Recitation',
    audioBaseUrl: 'https://cdn.islamic.network/quran/audio/128/ar.alafasy',
  },
  {
    id: 'maher_almuaiqly',
    name: 'Maher Al-Muaiqly',
    arabicName: 'ماهر المعيقلي',
    style: 'Imam of Masjid al-Haram',
    audioBaseUrl: 'https://cdn.islamic.network/quran/audio/128/ar.maabormuaiqly',
  },
  {
    id: 'saad_alghamdi',
    name: 'Saad Al-Ghamdi',
    arabicName: 'سعد الغامدي',
    style: 'Clear Tajweed Recitation',
    audioBaseUrl: 'https://cdn.islamic.network/quran/audio/128/ar.saoodshuraym',
  },
  {
    id: 'abdul_basit',
    name: 'Abdul Basit Abdul Samad',
    arabicName: 'عبدالباسط عبدالصمد',
    style: 'Classical Egyptian Style',
    audioBaseUrl: 'https://cdn.islamic.network/quran/audio/64/ar.abdulbasitmurattal',
  },
];

// All 114 Surahs
export const surahs: Surah[] = [
  { id: 1, name: 'Al-Fatiha', arabicName: 'الفاتحة', englishName: 'The Opening', meaning: 'The Opening', verses: 7, type: 'Meccan', order: 5 },
  { id: 2, name: 'Al-Baqarah', arabicName: 'البقرة', englishName: 'The Cow', meaning: 'The Cow', verses: 286, type: 'Medinan', order: 87 },
  { id: 3, name: 'Aal-E-Imran', arabicName: 'آل عمران', englishName: 'The Family of Imran', meaning: 'The Family of Imran', verses: 200, type: 'Medinan', order: 89 },
  { id: 4, name: 'An-Nisa', arabicName: 'النساء', englishName: 'The Women', meaning: 'The Women', verses: 176, type: 'Medinan', order: 92 },
  { id: 5, name: 'Al-Maidah', arabicName: 'المائدة', englishName: 'The Table', meaning: 'The Table Spread', verses: 120, type: 'Medinan', order: 112 },
  { id: 6, name: 'Al-Anam', arabicName: 'الأنعام', englishName: 'The Cattle', meaning: 'The Cattle', verses: 165, type: 'Meccan', order: 55 },
  { id: 7, name: 'Al-Araf', arabicName: 'الأعراف', englishName: 'The Heights', meaning: 'The Heights', verses: 206, type: 'Meccan', order: 39 },
  { id: 8, name: 'Al-Anfal', arabicName: 'الأنفال', englishName: 'The Spoils of War', meaning: 'The Spoils of War', verses: 75, type: 'Medinan', order: 88 },
  { id: 9, name: 'At-Tawbah', arabicName: 'التوبة', englishName: 'The Repentance', meaning: 'The Repentance', verses: 129, type: 'Medinan', order: 113 },
  { id: 10, name: 'Yunus', arabicName: 'يونس', englishName: 'Jonah', meaning: 'Jonah', verses: 109, type: 'Meccan', order: 51 },
  { id: 11, name: 'Hud', arabicName: 'هود', englishName: 'Hud', meaning: 'Hud', verses: 123, type: 'Meccan', order: 52 },
  { id: 12, name: 'Yusuf', arabicName: 'يوسف', englishName: 'Joseph', meaning: 'Joseph', verses: 111, type: 'Meccan', order: 53 },
  { id: 13, name: 'Ar-Rad', arabicName: 'الرعد', englishName: 'The Thunder', meaning: 'The Thunder', verses: 43, type: 'Medinan', order: 96 },
  { id: 14, name: 'Ibrahim', arabicName: 'إبراهيم', englishName: 'Abraham', meaning: 'Abraham', verses: 52, type: 'Meccan', order: 72 },
  { id: 15, name: 'Al-Hijr', arabicName: 'الحجر', englishName: 'The Rocky Tract', meaning: 'The Rocky Tract', verses: 99, type: 'Meccan', order: 54 },
  { id: 16, name: 'An-Nahl', arabicName: 'النحل', englishName: 'The Bee', meaning: 'The Bee', verses: 128, type: 'Meccan', order: 70 },
  { id: 17, name: 'Al-Isra', arabicName: 'الإسراء', englishName: 'The Night Journey', meaning: 'The Night Journey', verses: 111, type: 'Meccan', order: 50 },
  { id: 18, name: 'Al-Kahf', arabicName: 'الكهف', englishName: 'The Cave', meaning: 'The Cave', verses: 110, type: 'Meccan', order: 69 },
  { id: 19, name: 'Maryam', arabicName: 'مريم', englishName: 'Mary', meaning: 'Mary', verses: 98, type: 'Meccan', order: 44 },
  { id: 20, name: 'Ta-Ha', arabicName: 'طه', englishName: 'Ta-Ha', meaning: 'Ta-Ha', verses: 135, type: 'Meccan', order: 45 },
  { id: 21, name: 'Al-Anbiya', arabicName: 'الأنبياء', englishName: 'The Prophets', meaning: 'The Prophets', verses: 112, type: 'Meccan', order: 73 },
  { id: 22, name: 'Al-Hajj', arabicName: 'الحج', englishName: 'The Pilgrimage', meaning: 'The Pilgrimage', verses: 78, type: 'Medinan', order: 103 },
  { id: 23, name: 'Al-Muminun', arabicName: 'المؤمنون', englishName: 'The Believers', meaning: 'The Believers', verses: 118, type: 'Meccan', order: 74 },
  { id: 24, name: 'An-Nur', arabicName: 'النور', englishName: 'The Light', meaning: 'The Light', verses: 64, type: 'Medinan', order: 102 },
  { id: 25, name: 'Al-Furqan', arabicName: 'الفرقان', englishName: 'The Criterion', meaning: 'The Criterion', verses: 77, type: 'Meccan', order: 42 },
  { id: 26, name: 'Ash-Shuara', arabicName: 'الشعراء', englishName: 'The Poets', meaning: 'The Poets', verses: 227, type: 'Meccan', order: 47 },
  { id: 27, name: 'An-Naml', arabicName: 'النمل', englishName: 'The Ant', meaning: 'The Ant', verses: 93, type: 'Meccan', order: 48 },
  { id: 28, name: 'Al-Qasas', arabicName: 'القصص', englishName: 'The Stories', meaning: 'The Stories', verses: 88, type: 'Meccan', order: 49 },
  { id: 29, name: 'Al-Ankabut', arabicName: 'العنكبوت', englishName: 'The Spider', meaning: 'The Spider', verses: 69, type: 'Meccan', order: 85 },
  { id: 30, name: 'Ar-Rum', arabicName: 'الروم', englishName: 'The Romans', meaning: 'The Romans', verses: 60, type: 'Meccan', order: 84 },
  { id: 31, name: 'Luqman', arabicName: 'لقمان', englishName: 'Luqman', meaning: 'Luqman', verses: 34, type: 'Meccan', order: 57 },
  { id: 32, name: 'As-Sajdah', arabicName: 'السجدة', englishName: 'The Prostration', meaning: 'The Prostration', verses: 30, type: 'Meccan', order: 75 },
  { id: 33, name: 'Al-Ahzab', arabicName: 'الأحزاب', englishName: 'The Combined Forces', meaning: 'The Combined Forces', verses: 73, type: 'Medinan', order: 90 },
  { id: 34, name: 'Saba', arabicName: 'سبأ', englishName: 'Sheba', meaning: 'Sheba', verses: 54, type: 'Meccan', order: 58 },
  { id: 35, name: 'Fatir', arabicName: 'فاطر', englishName: 'The Originator', meaning: 'The Originator', verses: 45, type: 'Meccan', order: 43 },
  { id: 36, name: 'Ya-Sin', arabicName: 'يس', englishName: 'Ya-Sin', meaning: 'Ya-Sin', verses: 83, type: 'Meccan', order: 41 },
  { id: 37, name: 'As-Saffat', arabicName: 'الصافات', englishName: 'Those Lined Up', meaning: 'Those Lined Up', verses: 182, type: 'Meccan', order: 56 },
  { id: 38, name: 'Sad', arabicName: 'ص', englishName: 'Sad', meaning: 'Sad', verses: 88, type: 'Meccan', order: 38 },
  { id: 39, name: 'Az-Zumar', arabicName: 'الزمر', englishName: 'The Groups', meaning: 'The Groups', verses: 75, type: 'Meccan', order: 59 },
  { id: 40, name: 'Ghafir', arabicName: 'غافر', englishName: 'The Forgiver', meaning: 'The Forgiver', verses: 85, type: 'Meccan', order: 60 },
  { id: 41, name: 'Fussilat', arabicName: 'فصلت', englishName: 'Explained in Detail', meaning: 'Explained in Detail', verses: 54, type: 'Meccan', order: 61 },
  { id: 42, name: 'Ash-Shura', arabicName: 'الشورى', englishName: 'The Consultation', meaning: 'The Consultation', verses: 53, type: 'Meccan', order: 62 },
  { id: 43, name: 'Az-Zukhruf', arabicName: 'الزخرف', englishName: 'The Gold', meaning: 'The Gold', verses: 89, type: 'Meccan', order: 63 },
  { id: 44, name: 'Ad-Dukhan', arabicName: 'الدخان', englishName: 'The Smoke', meaning: 'The Smoke', verses: 59, type: 'Meccan', order: 64 },
  { id: 45, name: 'Al-Jathiyah', arabicName: 'الجاثية', englishName: 'The Kneeling', meaning: 'The Kneeling', verses: 37, type: 'Meccan', order: 65 },
  { id: 46, name: 'Al-Ahqaf', arabicName: 'الأحقاف', englishName: 'The Sand Dunes', meaning: 'The Sand Dunes', verses: 35, type: 'Meccan', order: 66 },
  { id: 47, name: 'Muhammad', arabicName: 'محمد', englishName: 'Muhammad', meaning: 'Muhammad', verses: 38, type: 'Medinan', order: 95 },
  { id: 48, name: 'Al-Fath', arabicName: 'الفتح', englishName: 'The Victory', meaning: 'The Victory', verses: 29, type: 'Medinan', order: 111 },
  { id: 49, name: 'Al-Hujurat', arabicName: 'الحجرات', englishName: 'The Dwellings', meaning: 'The Dwellings', verses: 18, type: 'Medinan', order: 106 },
  { id: 50, name: 'Qaf', arabicName: 'ق', englishName: 'Qaf', meaning: 'Qaf', verses: 45, type: 'Meccan', order: 34 },
  { id: 51, name: 'Adh-Dhariyat', arabicName: 'الذاريات', englishName: 'The Scattering Winds', meaning: 'The Scattering Winds', verses: 60, type: 'Meccan', order: 67 },
  { id: 52, name: 'At-Tur', arabicName: 'الطور', englishName: 'The Mount', meaning: 'The Mount', verses: 49, type: 'Meccan', order: 76 },
  { id: 53, name: 'An-Najm', arabicName: 'النجم', englishName: 'The Star', meaning: 'The Star', verses: 62, type: 'Meccan', order: 23 },
  { id: 54, name: 'Al-Qamar', arabicName: 'القمر', englishName: 'The Moon', meaning: 'The Moon', verses: 55, type: 'Meccan', order: 37 },
  { id: 55, name: 'Ar-Rahman', arabicName: 'الرحمن', englishName: 'The Most Merciful', meaning: 'The Most Merciful', verses: 78, type: 'Medinan', order: 97 },
  { id: 56, name: 'Al-Waqiah', arabicName: 'الواقعة', englishName: 'The Event', meaning: 'The Event', verses: 96, type: 'Meccan', order: 46 },
  { id: 57, name: 'Al-Hadid', arabicName: 'الحديد', englishName: 'The Iron', meaning: 'The Iron', verses: 29, type: 'Medinan', order: 94 },
  { id: 58, name: 'Al-Mujadila', arabicName: 'المجادلة', englishName: 'The Pleading Woman', meaning: 'The Pleading Woman', verses: 22, type: 'Medinan', order: 105 },
  { id: 59, name: 'Al-Hashr', arabicName: 'الحشر', englishName: 'The Gathering', meaning: 'The Gathering', verses: 24, type: 'Medinan', order: 101 },
  { id: 60, name: 'Al-Mumtahanah', arabicName: 'الممتحنة', englishName: 'The Examined One', meaning: 'The Examined One', verses: 13, type: 'Medinan', order: 91 },
  { id: 61, name: 'As-Saff', arabicName: 'الصف', englishName: 'The Row', meaning: 'The Row', verses: 14, type: 'Medinan', order: 109 },
  { id: 62, name: 'Al-Jumuah', arabicName: 'الجمعة', englishName: 'Friday', meaning: 'Friday', verses: 11, type: 'Medinan', order: 110 },
  { id: 63, name: 'Al-Munafiqun', arabicName: 'المنافقون', englishName: 'The Hypocrites', meaning: 'The Hypocrites', verses: 11, type: 'Medinan', order: 104 },
  { id: 64, name: 'At-Taghabun', arabicName: 'التغابن', englishName: 'Loss and Gain', meaning: 'Loss and Gain', verses: 18, type: 'Medinan', order: 108 },
  { id: 65, name: 'At-Talaq', arabicName: 'الطلاق', englishName: 'The Divorce', meaning: 'The Divorce', verses: 12, type: 'Medinan', order: 99 },
  { id: 66, name: 'At-Tahrim', arabicName: 'التحريم', englishName: 'The Prohibition', meaning: 'The Prohibition', verses: 12, type: 'Medinan', order: 107 },
  { id: 67, name: 'Al-Mulk', arabicName: 'الملك', englishName: 'The Kingdom', meaning: 'The Kingdom', verses: 30, type: 'Meccan', order: 77 },
  { id: 68, name: 'Al-Qalam', arabicName: 'القلم', englishName: 'The Pen', meaning: 'The Pen', verses: 52, type: 'Meccan', order: 2 },
  { id: 69, name: 'Al-Haqqah', arabicName: 'الحاقة', englishName: 'The Inevitable', meaning: 'The Inevitable', verses: 52, type: 'Meccan', order: 78 },
  { id: 70, name: 'Al-Maarij', arabicName: 'المعارج', englishName: 'The Ways of Ascent', meaning: 'The Ways of Ascent', verses: 44, type: 'Meccan', order: 79 },
  { id: 71, name: 'Nuh', arabicName: 'نوح', englishName: 'Noah', meaning: 'Noah', verses: 28, type: 'Meccan', order: 71 },
  { id: 72, name: 'Al-Jinn', arabicName: 'الجن', englishName: 'The Jinn', meaning: 'The Jinn', verses: 28, type: 'Meccan', order: 40 },
  { id: 73, name: 'Al-Muzzammil', arabicName: 'المزمل', englishName: 'The Wrapped One', meaning: 'The Wrapped One', verses: 20, type: 'Meccan', order: 3 },
  { id: 74, name: 'Al-Muddathir', arabicName: 'المدثر', englishName: 'The Cloaked One', meaning: 'The Cloaked One', verses: 56, type: 'Meccan', order: 4 },
  { id: 75, name: 'Al-Qiyamah', arabicName: 'القيامة', englishName: 'The Resurrection', meaning: 'The Resurrection', verses: 40, type: 'Meccan', order: 31 },
  { id: 76, name: 'Al-Insan', arabicName: 'الإنسان', englishName: 'The Human', meaning: 'The Human', verses: 31, type: 'Medinan', order: 98 },
  { id: 77, name: 'Al-Mursalat', arabicName: 'المرسلات', englishName: 'Those Sent Forth', meaning: 'Those Sent Forth', verses: 50, type: 'Meccan', order: 33 },
  { id: 78, name: 'An-Naba', arabicName: 'النبأ', englishName: 'The News', meaning: 'The News', verses: 40, type: 'Meccan', order: 80 },
  { id: 79, name: 'An-Naziat', arabicName: 'النازعات', englishName: 'Those Who Pull Out', meaning: 'Those Who Pull Out', verses: 46, type: 'Meccan', order: 81 },
  { id: 80, name: 'Abasa', arabicName: 'عبس', englishName: 'He Frowned', meaning: 'He Frowned', verses: 42, type: 'Meccan', order: 24 },
  { id: 81, name: 'At-Takwir', arabicName: 'التكوير', englishName: 'The Overthrowing', meaning: 'The Overthrowing', verses: 29, type: 'Meccan', order: 7 },
  { id: 82, name: 'Al-Infitar', arabicName: 'الانفطار', englishName: 'The Cleaving', meaning: 'The Cleaving', verses: 19, type: 'Meccan', order: 82 },
  { id: 83, name: 'Al-Mutaffifin', arabicName: 'المطففين', englishName: 'Those Who Deal in Fraud', meaning: 'Those Who Deal in Fraud', verses: 36, type: 'Meccan', order: 86 },
  { id: 84, name: 'Al-Inshiqaq', arabicName: 'الانشقاق', englishName: 'The Splitting Asunder', meaning: 'The Splitting Asunder', verses: 25, type: 'Meccan', order: 83 },
  { id: 85, name: 'Al-Buruj', arabicName: 'البروج', englishName: 'The Stars', meaning: 'The Stars', verses: 22, type: 'Meccan', order: 27 },
  { id: 86, name: 'At-Tariq', arabicName: 'الطارق', englishName: 'The Night Visitor', meaning: 'The Night Visitor', verses: 17, type: 'Meccan', order: 36 },
  { id: 87, name: 'Al-Ala', arabicName: 'الأعلى', englishName: 'The Most High', meaning: 'The Most High', verses: 19, type: 'Meccan', order: 8 },
  { id: 88, name: 'Al-Ghashiyah', arabicName: 'الغاشية', englishName: 'The Overwhelming', meaning: 'The Overwhelming', verses: 26, type: 'Meccan', order: 68 },
  { id: 89, name: 'Al-Fajr', arabicName: 'الفجر', englishName: 'The Dawn', meaning: 'The Dawn', verses: 30, type: 'Meccan', order: 10 },
  { id: 90, name: 'Al-Balad', arabicName: 'البلد', englishName: 'The City', meaning: 'The City', verses: 20, type: 'Meccan', order: 35 },
  { id: 91, name: 'Ash-Shams', arabicName: 'الشمس', englishName: 'The Sun', meaning: 'The Sun', verses: 15, type: 'Meccan', order: 26 },
  { id: 92, name: 'Al-Layl', arabicName: 'الليل', englishName: 'The Night', meaning: 'The Night', verses: 21, type: 'Meccan', order: 9 },
  { id: 93, name: 'Ad-Duha', arabicName: 'الضحى', englishName: 'The Morning Hours', meaning: 'The Morning Hours', verses: 11, type: 'Meccan', order: 11 },
  { id: 94, name: 'Ash-Sharh', arabicName: 'الشرح', englishName: 'The Relief', meaning: 'The Relief', verses: 8, type: 'Meccan', order: 12 },
  { id: 95, name: 'At-Tin', arabicName: 'التين', englishName: 'The Fig', meaning: 'The Fig', verses: 8, type: 'Meccan', order: 28 },
  { id: 96, name: 'Al-Alaq', arabicName: 'العلق', englishName: 'The Clot', meaning: 'The Clot', verses: 19, type: 'Meccan', order: 1 },
  { id: 97, name: 'Al-Qadr', arabicName: 'القدر', englishName: 'The Night of Decree', meaning: 'The Night of Decree', verses: 5, type: 'Meccan', order: 25 },
  { id: 98, name: 'Al-Bayyinah', arabicName: 'البينة', englishName: 'The Clear Evidence', meaning: 'The Clear Evidence', verses: 8, type: 'Medinan', order: 100 },
  { id: 99, name: 'Az-Zalzalah', arabicName: 'الزلزلة', englishName: 'The Earthquake', meaning: 'The Earthquake', verses: 8, type: 'Medinan', order: 93 },
  { id: 100, name: 'Al-Adiyat', arabicName: 'العاديات', englishName: 'The Charging Steeds', meaning: 'The Charging Steeds', verses: 11, type: 'Meccan', order: 14 },
  { id: 101, name: 'Al-Qariah', arabicName: 'القارعة', englishName: 'The Calamity', meaning: 'The Calamity', verses: 11, type: 'Meccan', order: 30 },
  { id: 102, name: 'At-Takathur', arabicName: 'التكاثر', englishName: 'Competition', meaning: 'Competition', verses: 8, type: 'Meccan', order: 16 },
  { id: 103, name: 'Al-Asr', arabicName: 'العصر', englishName: 'The Time', meaning: 'The Time', verses: 3, type: 'Meccan', order: 13 },
  { id: 104, name: 'Al-Humazah', arabicName: 'الهمزة', englishName: 'The Slanderer', meaning: 'The Slanderer', verses: 9, type: 'Meccan', order: 32 },
  { id: 105, name: 'Al-Fil', arabicName: 'الفيل', englishName: 'The Elephant', meaning: 'The Elephant', verses: 5, type: 'Meccan', order: 19 },
  { id: 106, name: 'Quraysh', arabicName: 'قريش', englishName: 'Quraysh', meaning: 'Quraysh', verses: 4, type: 'Meccan', order: 29 },
  { id: 107, name: 'Al-Maun', arabicName: 'الماعون', englishName: 'The Small Kindnesses', meaning: 'The Small Kindnesses', verses: 7, type: 'Meccan', order: 17 },
  { id: 108, name: 'Al-Kawthar', arabicName: 'الكوثر', englishName: 'The Abundance', meaning: 'The Abundance', verses: 3, type: 'Meccan', order: 15 },
  { id: 109, name: 'Al-Kafirun', arabicName: 'الكافرون', englishName: 'The Disbelievers', meaning: 'The Disbelievers', verses: 6, type: 'Meccan', order: 18 },
  { id: 110, name: 'An-Nasr', arabicName: 'النصر', englishName: 'The Help', meaning: 'The Help', verses: 3, type: 'Medinan', order: 114 },
  { id: 111, name: 'Al-Masad', arabicName: 'المسد', englishName: 'The Palm Fiber', meaning: 'The Palm Fiber', verses: 5, type: 'Meccan', order: 6 },
  { id: 112, name: 'Al-Ikhlas', arabicName: 'الإخلاص', englishName: 'The Sincerity', meaning: 'The Sincerity', verses: 4, type: 'Meccan', order: 22 },
  { id: 113, name: 'Al-Falaq', arabicName: 'الفلق', englishName: 'The Daybreak', meaning: 'The Daybreak', verses: 5, type: 'Meccan', order: 20 },
  { id: 114, name: 'An-Nas', arabicName: 'الناس', englishName: 'Mankind', meaning: 'Mankind', verses: 6, type: 'Meccan', order: 21 },
];

// Helper function to get audio URL for a specific ayah
export function getAyahAudioUrl(reciterId: string, surahNumber: number, ayahNumber: number): string {
  const reciter = reciters.find(r => r.id === reciterId);
  if (!reciter) {
    // Default to Mishary Alafasy
    return `https://cdn.islamic.network/quran/audio/128/ar.alafasy/${surahNumber}:${ayahNumber}.mp3`;
  }

  // Calculate the absolute ayah number (1-6236)
  const absoluteAyahNumber = getAbsoluteAyahNumber(surahNumber, ayahNumber);
  return `${reciter.audioBaseUrl}/${absoluteAyahNumber}.mp3`;
}

// Get audio URL for full surah
export function getSurahAudioUrl(reciterId: string, surahNumber: number): string {
  // These URLs provide full surah recitation
  const paddedSurah = surahNumber.toString().padStart(3, '0');

  switch (reciterId) {
    case 'abdurrahman_alsudais':
      return `https://server8.mp3quran.net/afs/${paddedSurah}.mp3`;
    case 'mishary_alafasy':
      return `https://server8.mp3quran.net/afs/${paddedSurah}.mp3`;
    case 'maher_almuaiqly':
      return `https://server12.mp3quran.net/maher/${paddedSurah}.mp3`;
    case 'saad_alghamdi':
      return `https://server7.mp3quran.net/s_gmd/${paddedSurah}.mp3`;
    case 'abdul_basit':
      return `https://server7.mp3quran.net/basit/${paddedSurah}.mp3`;
    default:
      return `https://server8.mp3quran.net/afs/${paddedSurah}.mp3`;
  }
}

// Calculate absolute ayah number across all surahs
function getAbsoluteAyahNumber(surahNumber: number, ayahNumber: number): number {
  const ayahCounts = [
    0, 7, 286, 200, 176, 120, 165, 206, 75, 129, 109,
    123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
    112, 78, 118, 64, 77, 227, 93, 88, 69, 60,
    34, 30, 73, 54, 45, 83, 182, 88, 75, 85,
    54, 53, 89, 59, 37, 35, 38, 29, 18, 45,
    60, 49, 62, 55, 78, 96, 29, 22, 24, 13,
    14, 11, 11, 18, 12, 12, 30, 52, 52, 44,
    28, 28, 20, 56, 40, 31, 50, 40, 46, 42,
    29, 19, 36, 25, 22, 17, 19, 26, 30, 20,
    15, 21, 11, 8, 8, 19, 5, 8, 8, 11,
    11, 8, 3, 9, 5, 4, 7, 3, 6, 3,
    5, 4, 5, 6
  ];

  let total = 0;
  for (let i = 1; i < surahNumber; i++) {
    total += ayahCounts[i];
  }
  return total + ayahNumber;
}

// Sample ayahs for Al-Fatiha (Surah 1)
export const alFatihaAyahs: Ayah[] = [
  {
    number: 1,
    arabic: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
    translation: 'In the name of Allah, the Entirely Merciful, the Especially Merciful.',
    translationUrdu: 'اللہ کے نام سے جو بڑا مہربان نہایت رحم والا ہے',
    transliteration: 'Bismillahir Rahmanir Raheem',
  },
  {
    number: 2,
    arabic: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
    translation: 'All praise is due to Allah, Lord of the worlds.',
    translationUrdu: 'سب تعریف اللہ کے لیے ہے جو تمام جہانوں کا پالنے والا ہے',
    transliteration: 'Alhamdu lillahi rabbil alameen',
  },
  {
    number: 3,
    arabic: 'الرَّحْمَٰنِ الرَّحِيمِ',
    translation: 'The Entirely Merciful, the Especially Merciful.',
    translationUrdu: 'بڑا مہربان نہایت رحم والا',
    transliteration: 'Ar-Rahmanir Raheem',
  },
  {
    number: 4,
    arabic: 'مَالِكِ يَوْمِ الدِّينِ',
    translation: 'Sovereign of the Day of Recompense.',
    translationUrdu: 'روزِ جزا کا مالک',
    transliteration: 'Maliki yawmid deen',
  },
  {
    number: 5,
    arabic: 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ',
    translation: 'You alone we worship, and You alone we ask for help.',
    translationUrdu: 'ہم تیری ہی عبادت کرتے ہیں اور تجھ ہی سے مدد چاہتے ہیں',
    transliteration: 'Iyyaka nabudu wa iyyaka nastaeen',
  },
  {
    number: 6,
    arabic: 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ',
    translation: 'Guide us to the straight path.',
    translationUrdu: 'ہمیں سیدھا راستہ دکھا',
    transliteration: 'Ihdinas siratal mustaqeem',
  },
  {
    number: 7,
    arabic: 'صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ',
    translation: 'The path of those upon whom You have bestowed favor, not of those who have earned Your anger or of those who are astray.',
    translationUrdu: 'ان لوگوں کا راستہ جن پر تو نے انعام فرمایا، ان کا نہیں جن پر غضب ہوا اور نہ گمراہوں کا',
    transliteration: 'Siratal latheena anamta alayhim, ghayril maghdubi alayhim wa lad dalleen',
  },
];
