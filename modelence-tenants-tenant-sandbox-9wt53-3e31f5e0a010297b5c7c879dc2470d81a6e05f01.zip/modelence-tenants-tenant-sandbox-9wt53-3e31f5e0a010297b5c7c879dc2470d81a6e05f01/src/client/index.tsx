import { Suspense, useState, useCallback } from 'react';
import { renderApp } from 'modelence/client';
import { toast, Toaster } from 'react-hot-toast';
import { RouterProvider } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

import { router } from './router';
import favicon from './assets/favicon.svg';
import './index.css';
import LoadingSpinner from './components/LoadingSpinner';
import SplashScreen from './components/SplashScreen';
import { useAutoLogin } from './lib/autoLogin';

const queryClient = new QueryClient();

// Check if this is the first visit in this session
const SPLASH_SHOWN_KEY = 'noorulquran_splash_shown';

function shouldShowSplash(): boolean {
  const shown = sessionStorage.getItem(SPLASH_SHOWN_KEY);
  if (!shown) {
    sessionStorage.setItem(SPLASH_SHOWN_KEY, 'true');
    return true;
  }
  return false;
}

function App() {
  useAutoLogin();
  const [showSplash, setShowSplash] = useState(shouldShowSplash);

  const handleSplashComplete = useCallback(() => {
    setShowSplash(false);
  }, []);

  return (
    <>
      {showSplash && <SplashScreen onComplete={handleSplashComplete} duration={3500} />}
      <Suspense fallback={<LoadingSpinner fullScreen />}>
        <Toaster position="top-right" />
        <RouterProvider router={router} />
      </Suspense>
    </>
  );
}

renderApp({
  routesElement: (
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  ),
  errorHandler: (error) => {
    toast.error(error.message);
  },
  loadingElement: <LoadingSpinner fullScreen />,
  favicon
});
