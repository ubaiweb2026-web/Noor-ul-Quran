/** @type {import('tailwindcss').Config} */
export default {
    content: [
      "./src/client/**/*.{js,jsx,ts,tsx}",
    ],
    theme: {
      extend: {
        colors: {
          islamic: {
            green: {
              50: '#e8f5ec',
              100: '#c6e7cf',
              200: '#a1d7b1',
              300: '#7bc793',
              400: '#5fb97d',
              500: '#42ab67',
              600: '#3a9a5c',
              700: '#0f5e3b', // Primary requested color
              800: '#0d4f32',
              900: '#0a3d27',
            },
            gold: {
              50: '#fefce8',
              100: '#fef9c3',
              200: '#fef08a',
              300: '#fde047',
              400: '#facc15',
              500: '#d4a855',
              600: '#b8860b',
              700: '#92400e',
              800: '#78350f',
              900: '#451a03',
            },
            cream: '#faf8f5',
            ivory: '#fffff0',
            primary: '#0f5e3b',
          }
        },
        fontFamily: {
          arabic: ['Amiri', 'Noto Naskh Arabic', 'serif'],
        },
        backgroundImage: {
          'islamic-pattern': "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%230f5e3b' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")",
        },
        animation: {
          'glow': 'glow 2s ease-in-out infinite alternate',
          'float': 'float 3s ease-in-out infinite',
          'pulse-slow': 'pulse 3s ease-in-out infinite',
          'sound-wave': 'soundWave 1s ease-in-out infinite',
        },
        keyframes: {
          glow: {
            '0%': { boxShadow: '0 0 20px rgba(212, 168, 85, 0.3)' },
            '100%': { boxShadow: '0 0 40px rgba(212, 168, 85, 0.6)' },
          },
          float: {
            '0%, 100%': { transform: 'translateY(0)' },
            '50%': { transform: 'translateY(-10px)' },
          },
          soundWave: {
            '0%, 100%': { transform: 'scaleY(1)' },
            '50%': { transform: 'scaleY(1.5)' },
          },
        },
      },
    },
    plugins: [],
}
